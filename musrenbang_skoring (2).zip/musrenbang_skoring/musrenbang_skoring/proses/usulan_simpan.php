<?php
require_once __DIR__ . '/../includes/fungsi.php';
wajib_login();
periksa_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../usulan.php');
    exit;
}

$id          = (int)($_POST['id_usulan'] ?? 0);
$tahun       = (int)$_POST['tahun'];
$id_kec      = kec_user() > 0 ? kec_user() : (int)($_POST['id_kecamatan'] ?? 0);
$desa        = trim($_POST['desa'] ?? '');
$id_sumber   = (int)$_POST['id_sumber'];
$id_sektor   = (int)$_POST['id_sektor'];
$id_opd      = (int)$_POST['id_opd'];
$nama        = trim($_POST['nama_usulan'] ?? '');
$uraian      = trim($_POST['uraian_masalah'] ?? '');
$volume      = (float)($_POST['volume'] ?? 0);
$satuan      = trim($_POST['satuan'] ?? '');
$anggaran    = (float)($_POST['estimasi_anggaran'] ?? 0);
$skor        = $_POST['skor'] ?? [];

$status  = boleh('admin','verifikator') ? ($_POST['status'] ?? 'Draft') : 'Draft';
$catatan = boleh('admin','verifikator') ? trim($_POST['catatan_verifikasi'] ?? '') : '';

if ($nama === '' || $desa === '' || $id_kec <= 0 || $id_sektor <= 0 || $id_opd <= 0) {
    pesan_set('galat', 'Isian wajib belum lengkap. Periksa kecamatan, desa, sektor, OPD, dan nama usulan.');
    header('Location: ../usulan_form.php' . ($id ? '?id=' . $id : ''));
    exit;
}

/* Desa wajib sesuai master desa kecamatan tersebut, bila master sudah diisi */
$peta_desa = ambil_peta_desa($koneksi);
$desa_lama = null;
if ($id > 0) {
    $b = jalankan($koneksi, "SELECT id_kecamatan, desa FROM tb_usulan WHERE id_usulan = ?", 'i', [$id]);
    if ($b && (int)$b[0]['id_kecamatan'] === $id_kec) {
        $desa_lama = $b[0]['desa'];
    }
}
if (!empty($peta_desa[$id_kec]) && !in_array($desa, $peta_desa[$id_kec], true) && $desa !== $desa_lama) {
    pesan_set('galat', 'Desa "' . $desa . '" tidak terdaftar pada kecamatan yang dipilih. Pilih desa dari daftar.');
    header('Location: ../usulan_form.php' . ($id ? '?id=' . $id : ''));
    exit;
}

if ($id > 0) {
    $lama = jalankan($koneksi, "SELECT * FROM tb_usulan WHERE id_usulan = ?", 'i', [$id]);
    if (!$lama) {
        pesan_set('galat', 'Usulan tidak ditemukan.');
        header('Location: ../usulan.php');
        exit;
    }
    if (!boleh_kecamatan((int)$lama[0]['id_kecamatan'])) {
        pesan_set('galat', 'Usulan ini berada di luar kecamatan akun Anda.');
        header('Location: ../usulan.php');
        exit;
    }
    if (peran() === 'operator' && kec_user() === 0 && (int)$lama[0]['id_user'] !== (int)$_SESSION['id_user']) {
        pesan_set('galat', 'Operator hanya dapat mengubah usulan yang diinputnya sendiri.');
        header('Location: ../usulan.php');
        exit;
    }

    $stmt = mysqli_prepare($koneksi, "UPDATE tb_usulan SET
        tahun=?, id_kecamatan=?, desa=?, id_sumber=?, id_sektor=?, id_opd=?,
        nama_usulan=?, uraian_masalah=?, volume=?, satuan=?, estimasi_anggaran=?,
        status=?, catatan_verifikasi=? WHERE id_usulan=?");
    mysqli_stmt_bind_param($stmt, 'iisiiissdsdssi',
        $tahun, $id_kec, $desa, $id_sumber, $id_sektor, $id_opd,
        $nama, $uraian, $volume, $satuan, $anggaran, $status, $catatan, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $hasil = simpan_skor($koneksi, $id, $skor);
    catat_log($koneksi, 'ubah usulan', 'tb_usulan#' . $id,
        'Nilai akhir ' . $hasil['total'] . ' kategori ' . ($hasil['kategori']['nama'] ?? '-'));
    pesan_set('sukses', 'Perubahan tersimpan. Nilai akhir ' . angka($hasil['total'])
        . ' dengan kategori ' . ($hasil['kategori']['nama'] ?? 'belum ditentukan') . '.');
    header('Location: ../usulan_detail.php?id=' . $id);
    exit;
}

/* Usulan baru */
$nama_kec = jalankan($koneksi, "SELECT nama FROM tb_kecamatan WHERE id_kecamatan = ?", 'i', [$id_kec]);
$kode = buat_kode_usulan($koneksi, $tahun, $nama_kec[0]['nama'] ?? 'BANGGAI');
$id_user = (int)$_SESSION['id_user'];

$stmt = mysqli_prepare($koneksi, "INSERT INTO tb_usulan
    (kode_usulan, tahun, id_kecamatan, desa, id_sumber, id_sektor, id_opd,
     nama_usulan, uraian_masalah, volume, satuan, estimasi_anggaran,
     status, catatan_verifikasi, id_user)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
mysqli_stmt_bind_param($stmt, 'siisiiissdsdssi',
    $kode, $tahun, $id_kec, $desa, $id_sumber, $id_sektor, $id_opd,
    $nama, $uraian, $volume, $satuan, $anggaran, $status, $catatan, $id_user);

if (!mysqli_stmt_execute($stmt)) {
    pesan_set('galat', 'Usulan gagal disimpan: ' . mysqli_error($koneksi));
    header('Location: ../usulan_form.php');
    exit;
}
$id_baru = mysqli_insert_id($koneksi);
mysqli_stmt_close($stmt);

$hasil = simpan_skor($koneksi, $id_baru, $skor);
catat_log($koneksi, 'tambah usulan', 'tb_usulan#' . $id_baru,
    $kode . ' nilai ' . $hasil['total']);

pesan_set('sukses', 'Usulan ' . $kode . ' tersimpan dengan nilai akhir ' . angka($hasil['total'])
    . ' dan kategori ' . ($hasil['kategori']['nama'] ?? 'belum ditentukan') . '.');
header('Location: ../usulan_detail.php?id=' . $id_baru);
exit;
