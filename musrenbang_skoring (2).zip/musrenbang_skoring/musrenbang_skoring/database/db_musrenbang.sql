-- =====================================================================
-- SIMUSREN BANGGAI
-- Sistem Informasi Penjaringan dan Skoring Usulan Musrenbang
-- Bappeda Kabupaten Banggai
-- Basis data: db_musrenbang (MySQL / MariaDB)
-- Impor melalui phpMyAdmin: Import > pilih berkas ini > Go
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `db_musrenbang`
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_musrenbang`;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- 1. Pengguna
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id_user`      INT AUTO_INCREMENT PRIMARY KEY,
  `username`     VARCHAR(50)  NOT NULL UNIQUE,
  `password`     VARCHAR(255) NOT NULL,
  `nama_lengkap` VARCHAR(100) NOT NULL,
  `jabatan`      VARCHAR(100) DEFAULT NULL,
  `role`         ENUM('admin','verifikator','operator') NOT NULL DEFAULT 'operator',
  `id_kecamatan` INT DEFAULT NULL,
  `aktif`        TINYINT(1) NOT NULL DEFAULT 1,
  `dibuat_pada`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Kata sandi awal: admin123 / verifikator123 / operator123
INSERT INTO `tb_user` (`username`,`password`,`nama_lengkap`,`jabatan`,`role`,`id_kecamatan`) VALUES
('admin','$2y$10$S/aA3PZTZlEmidQg2JDyFONDpEOFB1dOvoG2m/2pYLKjshxF57k3O','Administrator','Bidang Infrastruktur dan Kewilayahan','admin',NULL),
('verifikator','$2y$10$KrRcnkqyuC4dR6td84hpVetTVOk5tDCnKMWKxeR2wBEfNrIU/FvsO','Verifikator Bappeda','Perencana','verifikator',NULL),
('operator','$2y$10$mOwNyLGstliUej0D.iqNheCQqiTnn7P..Oc8KQIUpMahe7bfQ2Nwe','Operator Kecamatan','Kasi PMD','operator',NULL);

-- ---------------------------------------------------------------------
-- 2. Referensi wilayah dan klasifikasi
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `tb_kecamatan`;
CREATE TABLE `tb_kecamatan` (
  `id_kecamatan` INT AUTO_INCREMENT PRIMARY KEY,
  `nama`         VARCHAR(80) NOT NULL,
  `aktif`        TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `tb_kecamatan` (`nama`) VALUES
('Balantak'),('Balantak Selatan'),('Balantak Utara'),('Batui'),('Batui Selatan'),
('Bualemo'),('Bunta'),('Kintom'),('Lamala'),('Lobu'),
('Luwuk'),('Luwuk Selatan'),('Luwuk Timur'),('Luwuk Utara'),('Mantoh'),
('Masama'),('Moilong'),('Nambo'),('Nuhon'),('Pagimana'),
('Simpang Raya'),('Toili'),('Toili Barat');

DROP TABLE IF EXISTS `tb_desa`;
CREATE TABLE `tb_desa` (
  `id_desa`      INT AUTO_INCREMENT PRIMARY KEY,
  `id_kecamatan` INT NOT NULL,
  `nama`         VARCHAR(100) NOT NULL,
  `jenis`        ENUM('Desa','Kelurahan') NOT NULL DEFAULT 'Desa',
  `aktif`        TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY `uq_kec_desa` (`id_kecamatan`,`nama`),
  CONSTRAINT `fk_desa_kec` FOREIGN KEY (`id_kecamatan`) REFERENCES `tb_kecamatan`(`id_kecamatan`)
) ENGINE=InnoDB;

-- Daftar desa/kelurahan diisi melalui menu Master > Desa/Kelurahan
-- (tempel dari Excel) atau dengan menambahkan INSERT di bawah ini, contoh:
-- INSERT INTO `tb_desa` (`id_kecamatan`,`nama`,`jenis`) VALUES
-- ((SELECT id_kecamatan FROM tb_kecamatan WHERE nama='Pagimana'),'Pisou','Desa');

-- Akun operator untuk setiap kecamatan.
-- Nama pengguna: kec_<nama kecamatan>, contoh kec_luwuk_selatan. Sandi awal: kecamatan123
INSERT IGNORE INTO `tb_user` (`username`,`password`,`nama_lengkap`,`jabatan`,`role`,`id_kecamatan`)
SELECT CONCAT('kec_', LOWER(REPLACE(`nama`,' ','_'))),
       '$2y$10$s6J9Qx2izv5/1ot.GrNcJe1Jn9I9mI1f.q4ZxRt/zSMhexRCwgHLO',
       CONCAT('Operator Kecamatan ', `nama`), 'Operator Kecamatan', 'operator', `id_kecamatan`
FROM `tb_kecamatan`;

DROP TABLE IF EXISTS `tb_sektor`;
CREATE TABLE `tb_sektor` (
  `id_sektor` INT AUTO_INCREMENT PRIMARY KEY,
  `nama`      VARCHAR(80) NOT NULL,
  `warna`     VARCHAR(9) NOT NULL DEFAULT '#0F766E',
  `aktif`     TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `tb_sektor` (`nama`,`warna`) VALUES
('Infrastruktur','#0F766E'),
('Lingkungan Hidup','#15803D'),
('Pendidikan','#1D4ED8'),
('Kesehatan','#BE123C'),
('Ekonomi','#B45309'),
('Sosial','#7C3AED'),
('Pemerintahan','#334155'),
('Kewilayahan','#0369A1');

DROP TABLE IF EXISTS `tb_sumber_usulan`;
CREATE TABLE `tb_sumber_usulan` (
  `id_sumber` INT AUTO_INCREMENT PRIMARY KEY,
  `nama`      VARCHAR(80) NOT NULL,
  `aktif`     TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `tb_sumber_usulan` (`nama`) VALUES
('Desa/Kelurahan'),('Musrenbang Kecamatan'),('Pokok Pikiran DPRD'),
('Forum OPD'),('Masyarakat/Komunitas'),('Lainnya');

DROP TABLE IF EXISTS `tb_opd`;
CREATE TABLE `tb_opd` (
  `id_opd` INT AUTO_INCREMENT PRIMARY KEY,
  `nama`   VARCHAR(120) NOT NULL,
  `aktif`  TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `tb_opd` (`nama`) VALUES
('Dinas PUPR'),('Dinas Perkimtan'),('DLH'),('Dinas Pendidikan'),('Dinas Kesehatan'),
('Dinas PMD'),('Dinas Sosial'),('Dinas Perdagangan'),('Dinas Perindag'),('Bappeda'),
('Dinas Perhubungan'),('Diskominfo'),('Dinas Ketahanan Pangan'),('BPBD'),
('Dinas Pertanian'),('Dinas Perikanan'),('Dinas lainnya');

-- ---------------------------------------------------------------------
-- 3. Kriteria penilaian dan bobot
--    nilai = (skor / skala_maksimum) x bobot
--    Total bobot wajib 100.
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `tb_kriteria`;
CREATE TABLE `tb_kriteria` (
  `id_kriteria`  INT AUTO_INCREMENT PRIMARY KEY,
  `kode`         VARCHAR(10) NOT NULL UNIQUE,
  `nama`         VARCHAR(100) NOT NULL,
  `deskripsi`    TEXT,
  `bobot`        DECIMAL(6,2) NOT NULL,
  `skala_maks`   TINYINT NOT NULL DEFAULT 5,
  `urut`         TINYINT NOT NULL DEFAULT 1,
  `aktif`        TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `tb_kriteria` (`kode`,`nama`,`deskripsi`,`bobot`,`skala_maks`,`urut`) VALUES
('K1','Urgensi','Tingkat kemendesakan penanganan masalah pada kondisi eksisting.',25.00,5,1),
('K2','Dampak/Manfaat','Luas sebaran penerima manfaat dan besaran dampak yang dihasilkan.',20.00,5,2),
('K3','Prioritas Pembangunan','Kesesuaian dengan prioritas RPJMD, RKPD, dan tema pembangunan tahun rencana.',15.00,5,3),
('K4','Kelayakan Teknis/Kewenangan','Kesesuaian kewenangan daerah, tata ruang, dan standar teknis kegiatan.',20.00,5,4),
('K5','Partisipasi','Tingkat keterlibatan dan dukungan masyarakat terhadap usulan.',10.00,5,5),
('K6','Kesiapan','Kesiapan lahan, dokumen perencanaan teknis, dan kesiapan pelaksanaan.',10.00,5,6);

DROP TABLE IF EXISTS `tb_kategori`;
CREATE TABLE `tb_kategori` (
  `id_kategori`  INT AUTO_INCREMENT PRIMARY KEY,
  `nama`         VARCHAR(60) NOT NULL,
  `batas_bawah`  DECIMAL(6,2) NOT NULL,
  `warna`        VARCHAR(9) NOT NULL DEFAULT '#64748B',
  `urut`         TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO `tb_kategori` (`nama`,`batas_bawah`,`warna`,`urut`) VALUES
('Prioritas Sangat Tinggi',90.00,'#065F46',1),
('Prioritas Tinggi',80.00,'#0F766E',2),
('Prioritas Sedang',70.00,'#B45309',3),
('Prioritas Rendah',60.00,'#C2410C',4),
('Tidak Prioritas',0.00,'#9F1239',5);

DROP TABLE IF EXISTS `tb_panduan_skor`;
CREATE TABLE `tb_panduan_skor` (
  `skor`      TINYINT PRIMARY KEY,
  `keterangan` VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `tb_panduan_skor` (`skor`,`keterangan`) VALUES
(5,'Sangat tinggi / sangat baik'),
(4,'Tinggi / baik'),
(3,'Sedang'),
(2,'Rendah'),
(1,'Sangat rendah / tidak siap');

-- ---------------------------------------------------------------------
-- 4. Usulan
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `tb_usulan`;
CREATE TABLE `tb_usulan` (
  `id_usulan`         INT AUTO_INCREMENT PRIMARY KEY,
  `kode_usulan`       VARCHAR(40) NOT NULL UNIQUE,
  `tahun`             SMALLINT NOT NULL,
  `id_kecamatan`      INT NOT NULL,
  `desa`              VARCHAR(100) NOT NULL,
  `id_sumber`         INT NOT NULL,
  `id_sektor`         INT NOT NULL,
  `id_opd`            INT NOT NULL,
  `nama_usulan`       VARCHAR(255) NOT NULL,
  `uraian_masalah`    TEXT,
  `volume`            DECIMAL(14,2) DEFAULT 0,
  `satuan`            VARCHAR(30) DEFAULT NULL,
  `estimasi_anggaran` DECIMAL(18,2) DEFAULT 0,
  `total_nilai`       DECIMAL(6,2) DEFAULT NULL,
  `id_kategori`       INT DEFAULT NULL,
  `status`            ENUM('Draft','Terverifikasi','Ditolak') NOT NULL DEFAULT 'Draft',
  `catatan_verifikasi` TEXT,
  `id_user`           INT DEFAULT NULL,
  `dibuat_pada`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `diubah_pada`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_tahun` (`tahun`),
  KEY `idx_kec` (`id_kecamatan`),
  KEY `idx_desa` (`id_kecamatan`,`desa`),
  KEY `idx_sektor` (`id_sektor`),
  KEY `idx_opd` (`id_opd`),
  KEY `idx_nilai` (`total_nilai`),
  CONSTRAINT `fk_usulan_kec` FOREIGN KEY (`id_kecamatan`) REFERENCES `tb_kecamatan`(`id_kecamatan`),
  CONSTRAINT `fk_usulan_sumber` FOREIGN KEY (`id_sumber`) REFERENCES `tb_sumber_usulan`(`id_sumber`),
  CONSTRAINT `fk_usulan_sektor` FOREIGN KEY (`id_sektor`) REFERENCES `tb_sektor`(`id_sektor`),
  CONSTRAINT `fk_usulan_opd` FOREIGN KEY (`id_opd`) REFERENCES `tb_opd`(`id_opd`)
) ENGINE=InnoDB;

-- Rincian skor per kriteria. Bobot ikut disimpan agar hasil dapat ditelusuri
-- kembali walaupun bobot induk berubah di kemudian hari.
DROP TABLE IF EXISTS `tb_usulan_skor`;
CREATE TABLE `tb_usulan_skor` (
  `id_skor`     INT AUTO_INCREMENT PRIMARY KEY,
  `id_usulan`   INT NOT NULL,
  `id_kriteria` INT NOT NULL,
  `skor`        TINYINT NOT NULL,
  `bobot`       DECIMAL(6,2) NOT NULL,
  `skala_maks`  TINYINT NOT NULL DEFAULT 5,
  `nilai`       DECIMAL(6,2) NOT NULL,
  UNIQUE KEY `uq_usulan_kriteria` (`id_usulan`,`id_kriteria`),
  CONSTRAINT `fk_skor_usulan` FOREIGN KEY (`id_usulan`) REFERENCES `tb_usulan`(`id_usulan`) ON DELETE CASCADE,
  CONSTRAINT `fk_skor_kriteria` FOREIGN KEY (`id_kriteria`) REFERENCES `tb_kriteria`(`id_kriteria`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. Jejak audit
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `tb_log`;
CREATE TABLE `tb_log` (
  `id_log`    INT AUTO_INCREMENT PRIMARY KEY,
  `id_user`   INT DEFAULT NULL,
  `username`  VARCHAR(50) DEFAULT NULL,
  `aksi`      VARCHAR(50) NOT NULL,
  `objek`     VARCHAR(120) DEFAULT NULL,
  `keterangan` TEXT,
  `ip`        VARCHAR(45) DEFAULT NULL,
  `waktu`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_waktu` (`waktu`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. Contoh usulan (sesuai baris contoh pada lembar kerja)
-- ---------------------------------------------------------------------
INSERT INTO `tb_usulan`
(`kode_usulan`,`tahun`,`id_kecamatan`,`desa`,`id_sumber`,`id_sektor`,`id_opd`,
 `nama_usulan`,`uraian_masalah`,`volume`,`satuan`,`estimasi_anggaran`,
 `total_nilai`,`id_kategori`,`status`,`id_user`)
VALUES
('USL-2027-PAGIMANA-0001',2027,
 (SELECT id_kecamatan FROM tb_kecamatan WHERE nama='Pagimana'),
 'Pisou',
 (SELECT id_sumber FROM tb_sumber_usulan WHERE nama='Desa/Kelurahan'),
 (SELECT id_sektor FROM tb_sektor WHERE nama='Infrastruktur'),
 (SELECT id_opd FROM tb_opd WHERE nama='Dinas PUPR'),
 'Pembangunan Jalan','Tidak ada jalan penghubung (buntu/rusak)',
 1000,'Meter',200000000,
 72.00,(SELECT id_kategori FROM tb_kategori WHERE nama='Prioritas Sedang'),
 'Draft',1);

INSERT INTO `tb_usulan_skor` (`id_usulan`,`id_kriteria`,`skor`,`bobot`,`skala_maks`,`nilai`) VALUES
(1,1,5,25.00,5,25.00),
(1,2,3,20.00,5,12.00),
(1,3,3,15.00,5,9.00),
(1,4,2,20.00,5,8.00),
(1,5,4,10.00,5,8.00),
(1,6,5,10.00,5,10.00);

SET FOREIGN_KEY_CHECKS = 1;
