<?php
require_once __DIR__ . '/includes/fungsi.php';
wajib_login();
wajib_peran('admin');

$halaman_aktif = 'pengguna';
$judul_halaman = 'User';

/* Nama pengguna otomatis untuk akun kecamatan: kec_luwuk_selatan */
function username_kecamatan(string $nama): string
{
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $nama), '_'));
    return 'kec_' . $slug;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    periksa_csrf();
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'tambah') {
        $username = trim($_POST['username'] ?? '');
        $nama     = trim($_POST['nama_lengkap'] ?? '');
        $jabatan  = trim($_POST['jabatan'] ?? '');
        $role     = in_array($_POST['role'] ?? '', ['admin','verifikator','operator'], true) ? $_POST['role'] : 'operator';
        $sandi    = $_POST['password'] ?? '';
        $id_kec   = ($_POST['id_kecamatan'] ?? '') !== '' ? (int)$_POST['id_kecamatan'] : null;

        if ($username === '' || strlen($sandi) < 6) {
            pesan_set('galat', 'Nama pengguna wajib diisi dan kata sandi minimal enam karakter.');
        } else {
            $hash = password_hash($sandi, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($koneksi, "INSERT INTO tb_user
                (username, password, nama_lengkap, jabatan, role, id_kecamatan) VALUES (?,?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, 'sssssi', $username, $hash, $nama, $jabatan, $role, $id_kec);
            if (mysqli_stmt_execute($stmt)) {
                catat_log($koneksi, 'tambah pengguna', 'tb_user', $username);
                pesan_set('sukses', 'Akun ' . $username . ' dibuat.');
            } else {
                pesan_set('galat', 'Akun gagal dibuat. Nama pengguna mungkin sudah dipakai.');
            }
            mysqli_stmt_close($stmt);
        }
    }

    /* Membuat satu akun operator untuk setiap kecamatan yang belum punya akun */
    if ($aksi === 'akun_kecamatan') {
        $sandi = $_POST['sandi_awal'] ?? '';
        if (strlen($sandi) < 6) {
            pesan_set('galat', 'Sandi awal minimal enam karakter.');
        } else {
            $hash = password_hash($sandi, PASSWORD_DEFAULT);
            $belum = jalankan($koneksi, "
                SELECT k.id_kecamatan, k.nama FROM tb_kecamatan k
                WHERE k.aktif = 1
                  AND NOT EXISTS (SELECT 1 FROM tb_user u WHERE u.id_kecamatan = k.id_kecamatan)
                ORDER BY k.nama");
            $dibuat = [];
            $stmt = mysqli_prepare($koneksi, "INSERT IGNORE INTO tb_user
                (username, password, nama_lengkap, jabatan, role, id_kecamatan)
                VALUES (?,?,?,'Operator Kecamatan','operator',?)");
            foreach ($belum as $k) {
                $un    = username_kecamatan($k['nama']);
                $nl    = 'Operator Kecamatan ' . $k['nama'];
                $idk   = (int)$k['id_kecamatan'];
                mysqli_stmt_bind_param($stmt, 'sssi', $un, $hash, $nl, $idk);
                mysqli_stmt_execute($stmt);
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    $dibuat[] = $un;
                }
            }
            mysqli_stmt_close($stmt);
            catat_log($koneksi, 'buat akun kecamatan', 'tb_user', count($dibuat) . ' akun');
            pesan_set('sukses', $dibuat
                ? count($dibuat) . ' akun kecamatan dibuat: ' . implode(', ', $dibuat) . '.'
                : 'Semua kecamatan aktif sudah memiliki akun.');
        }
    }

    if ($aksi === 'ubah') {
        $id      = (int)$_POST['id_user'];
        $role    = in_array($_POST['role'] ?? '', ['admin','verifikator','operator'], true) ? $_POST['role'] : 'operator';
        $id_kec  = ($_POST['id_kecamatan'] ?? '') !== '' ? (int)$_POST['id_kecamatan'] : null;
        $nama    = trim($_POST['nama_lengkap'] ?? '');
        if ($id === (int)$_SESSION['id_user'] && $role !== 'admin') {
            pesan_set('galat', 'Peran akun yang sedang dipakai tidak dapat diturunkan.');
        } elseif ($nama === '') {
            pesan_set('galat', 'Nama lengkap tidak boleh kosong.');
        } else {
            $stmt = mysqli_prepare($koneksi, "UPDATE tb_user SET nama_lengkap = ?, role = ?, id_kecamatan = ? WHERE id_user = ?");
            mysqli_stmt_bind_param($stmt, 'ssii', $nama, $role, $id_kec, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            catat_log($koneksi, 'ubah pengguna', 'tb_user#' . $id, $role . ' kec ' . ($id_kec ?? '-'));
            pesan_set('sukses', 'Data akun diperbarui. Perubahan berlaku saat akun tersebut masuk kembali.');
        }
    }

    if ($aksi === 'sandi') {
        $id    = (int)$_POST['id_user'];
        $sandi = $_POST['password_baru'] ?? '';
        if (strlen($sandi) < 6) {
            pesan_set('galat', 'Kata sandi baru minimal enam karakter.');
        } else {
            $hash = password_hash($sandi, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($koneksi, "UPDATE tb_user SET password = ? WHERE id_user = ?");
            mysqli_stmt_bind_param($stmt, 'si', $hash, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            catat_log($koneksi, 'ganti sandi', 'tb_user#' . $id, '');
            pesan_set('sukses', 'Kata sandi diperbarui.');
        }
    }

    if ($aksi === 'status') {
        $id = (int)$_POST['id_user'];
        if ($id === (int)$_SESSION['id_user']) {
            pesan_set('galat', 'Akun yang sedang dipakai tidak dapat dinonaktifkan.');
        } else {
            mysqli_query($koneksi, "UPDATE tb_user SET aktif = 1 - aktif WHERE id_user = $id");
            catat_log($koneksi, 'ubah status pengguna', 'tb_user#' . $id, '');
            pesan_set('sukses', 'Status akun diubah.');
        }
    }

    header('Location: pengguna.php' . (!empty($_POST['kembali']) ? '?' . $_POST['kembali'] : ''));
    exit;
}

/* Penyaring daftar */
$f_jenis = $_GET['jenis'] ?? '';
$f_cari  = trim($_GET['cari'] ?? '');
$syarat = ['1=1'];
$tipe = '';
$nilai = [];
if ($f_jenis === 'kecamatan') { $syarat[] = 'u.id_kecamatan IS NOT NULL'; }
if ($f_jenis === 'kabupaten') { $syarat[] = 'u.id_kecamatan IS NULL'; }
if ($f_cari !== '') {
    $syarat[] = '(u.username LIKE ? OR u.nama_lengkap LIKE ? OR k.nama LIKE ?)';
    $tipe = 'sss';
    $kata = '%' . $f_cari . '%';
    $nilai = [$kata, $kata, $kata];
}

$pengguna = jalankan($koneksi, "SELECT u.*, k.nama AS kecamatan,
        (SELECT COUNT(*) FROM tb_desa d WHERE d.id_kecamatan = u.id_kecamatan AND d.aktif = 1) AS jumlah_desa
    FROM tb_user u
    LEFT JOIN tb_kecamatan k ON k.id_kecamatan = u.id_kecamatan
    WHERE " . implode(' AND ', $syarat) . "
    ORDER BY (u.id_kecamatan IS NULL) DESC, u.role, k.nama, u.username", $tipe, $nilai);

$kecamatan = ambil_daftar($koneksi, 'tb_kecamatan', 'id_kecamatan');
$tanpa_akun = jalankan($koneksi, "SELECT COUNT(*) AS n FROM tb_kecamatan k WHERE k.aktif = 1
    AND NOT EXISTS (SELECT 1 FROM tb_user u WHERE u.id_kecamatan = k.id_kecamatan)")[0]['n'];
$kembali = http_build_query(array_filter(['jenis' => $f_jenis, 'cari' => $f_cari]));

require_once __DIR__ . '/includes/header.php';
?>

<div class="grid gap-5 lg:grid-cols-3">
  <div class="space-y-5">
    <form method="post" class="kartu p-5">
      <input type="hidden" name="csrf" value="<?= token_csrf() ?>">
      <input type="hidden" name="aksi" value="akun_kecamatan">
      <p class="font-semibold text-sm text-slate-800">Akun per kecamatan</p>
      <p class="text-xs text-slate-500 mt-1 mb-3">
        Setiap akun kecamatan hanya melihat usulan kecamatannya, dan pilihan desa pada formulir
        otomatis berisi desa milik kecamatan tersebut.
      </p>
      <?php if ((int)$tanpa_akun > 0): ?>
        <p class="text-sm text-slate-700 mb-3"><b><?= (int)$tanpa_akun ?></b> kecamatan belum memiliki akun.</p>
        <label class="block text-xs text-slate-600 mb-1">Sandi awal untuk akun baru</label>
        <input type="text" name="sandi_awal" value="kecamatan123" minlength="6" required class="isian mb-3">
        <button class="tombol w-full">Buat akun untuk <?= (int)$tanpa_akun ?> kecamatan</button>
        <p class="text-xs text-slate-500 mt-2">Nama pengguna dibuat otomatis, misalnya kec_luwuk_selatan.</p>
      <?php else: ?>
        <p class="text-sm text-emerald-700">Semua kecamatan aktif sudah memiliki akun.</p>
      <?php endif; ?>
    </form>

    <form method="post" class="kartu p-5">
      <input type="hidden" name="csrf" value="<?= token_csrf() ?>">
      <input type="hidden" name="aksi" value="tambah">
      <p class="font-semibold text-sm text-slate-800 mb-3">Buat akun baru</p>

      <label class="block text-xs text-slate-600 mb-1">Nama pengguna</label>
      <input name="username" required class="isian mb-3">

      <label class="block text-xs text-slate-600 mb-1">Nama lengkap</label>
      <input name="nama_lengkap" required class="isian mb-3">

      <label class="block text-xs text-slate-600 mb-1">Jabatan</label>
      <input name="jabatan" class="isian mb-3">

      <label class="block text-xs text-slate-600 mb-1">Peran</label>
      <select name="role" class="isian mb-3">
        <option value="operator">Operator, input usulan</option>
        <option value="verifikator">Verifikator, menilai dan memverifikasi</option>
        <option value="admin">Administrator, akses penuh</option>
      </select>

      <label class="block text-xs text-slate-600 mb-1">Kecamatan penugasan</label>
      <select name="id_kecamatan" class="isian mb-3">
        <option value="">Tingkat kabupaten (semua kecamatan)</option>
        <?php foreach ($kecamatan as $k): ?>
          <option value="<?= $k['id_kecamatan'] ?>"><?= e($k['nama']) ?></option>
        <?php endforeach; ?>
      </select>

      <label class="block text-xs text-slate-600 mb-1">Kata sandi awal</label>
      <input type="password" name="password" required minlength="6" class="isian mb-4">

      <button class="tombol w-full">Buat akun</button>
    </form>
  </div>

  <div class="lg:col-span-2 kartu overflow-hidden h-fit">
    <form method="get" class="px-4 py-3 border-b border-slate-200 flex flex-wrap items-end gap-3">
      <div>
        <p class="text-sm font-semibold text-slate-800">Daftar akun (<?= count($pengguna) ?>)</p>
      </div>
      <div class="ml-auto flex flex-wrap gap-2">
        <select name="jenis" class="isian" style="width:auto">
          <option value="">Semua akun</option>
          <option value="kabupaten" <?= $f_jenis === 'kabupaten' ? 'selected' : '' ?>>Tingkat kabupaten</option>
          <option value="kecamatan" <?= $f_jenis === 'kecamatan' ? 'selected' : '' ?>>Akun kecamatan</option>
        </select>
        <input name="cari" value="<?= e($f_cari) ?>" placeholder="Cari nama atau kecamatan" class="isian" style="width:200px">
        <button class="tombol-2">Cari</button>
      </div>
    </form>
    <div class="overflow-x-auto">
      <table class="data w-full">
        <thead><tr><th>Pengguna</th><th>Peran dan kecamatan</th><th>Status</th><th>Ganti sandi</th></tr></thead>
        <tbody>
        <?php foreach ($pengguna as $p): $fid = 'ubah' . (int)$p['id_user']; ?>
          <tr>
            <td>
              <span class="font-medium"><?= e($p['username']) ?></span>
              <input form="<?= $fid ?>" name="nama_lengkap" value="<?= e($p['nama_lengkap']) ?>" class="isian mt-1" style="min-width:190px">
              <?php if ($p['id_kecamatan']): ?>
                <div class="text-xs mt-1 <?= (int)$p['jumlah_desa'] > 0 ? 'text-slate-500' : 'text-amber-700' ?>">
                  <?= (int)$p['jumlah_desa'] > 0
                      ? (int)$p['jumlah_desa'] . ' desa terdaftar di Master'
                      : 'Desa kecamatan ini belum diisi di Master' ?>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <form method="post" id="<?= $fid ?>" class="flex flex-wrap gap-1 items-center">
                <input type="hidden" name="csrf" value="<?= token_csrf() ?>">
                <input type="hidden" name="aksi" value="ubah">
                <input type="hidden" name="kembali" value="<?= e($kembali) ?>">
                <input type="hidden" name="id_user" value="<?= (int)$p['id_user'] ?>">
                <select name="role" class="isian" style="width:120px">
                  <?php foreach (['operator','verifikator','admin'] as $r): ?>
                    <option value="<?= $r ?>" <?= $p['role'] === $r ? 'selected' : '' ?>><?= ucfirst($r) ?></option>
                  <?php endforeach; ?>
                </select>
                <select name="id_kecamatan" class="isian" style="width:170px">
                  <option value="">Kabupaten</option>
                  <?php foreach ($kecamatan as $k): ?>
                    <option value="<?= $k['id_kecamatan'] ?>" <?= (int)$p['id_kecamatan'] === (int)$k['id_kecamatan'] ? 'selected' : '' ?>><?= e($k['nama']) ?></option>
                  <?php endforeach; ?>
                </select>
                <button class="tombol-2 text-xs">Simpan</button>
              </form>
            </td>
            <td>
              <form method="post" class="inline">
                <input type="hidden" name="csrf" value="<?= token_csrf() ?>">
                <input type="hidden" name="aksi" value="status">
                <input type="hidden" name="kembali" value="<?= e($kembali) ?>">
                <input type="hidden" name="id_user" value="<?= (int)$p['id_user'] ?>">
                <button class="text-xs <?= $p['aktif'] ? 'text-slate-600' : 'text-rose-600' ?>">
                  <?= $p['aktif'] ? 'Aktif' : 'Nonaktif' ?>
                </button>
              </form>
            </td>
            <td>
              <form method="post" class="flex gap-1">
                <input type="hidden" name="csrf" value="<?= token_csrf() ?>">
                <input type="hidden" name="aksi" value="sandi">
                <input type="hidden" name="kembali" value="<?= e($kembali) ?>">
                <input type="hidden" name="id_user" value="<?= (int)$p['id_user'] ?>">
                <input type="password" name="password_baru" minlength="6" placeholder="Sandi baru"
                       class="isian" style="width:120px">
                <button class="tombol-2 text-xs">Simpan</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$pengguna): ?>
          <tr><td colspan="4" class="text-center text-slate-500 py-8">Tidak ada akun yang cocok dengan pencarian.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
