<?php
require_once __DIR__ . '/includes/fungsi.php';
wajib_login();

$id = (int)($_GET['id'] ?? 0);
$ubah = $id > 0;
$halaman_aktif = 'input';
$judul_halaman = $ubah ? 'Ubah usulan' : 'Input usulan';

$data = [
    'kode_usulan' => '(dibuat otomatis)',
    'tahun' => APP_TAHUN_DEFAULT, 'id_kecamatan' => '', 'desa' => '',
    'id_sumber' => '', 'id_sektor' => '', 'id_opd' => '',
    'nama_usulan' => '', 'uraian_masalah' => '', 'volume' => '', 'satuan' => '',
    'estimasi_anggaran' => '', 'status' => 'Draft', 'catatan_verifikasi' => '',
];
$skor_tersimpan = [];

if ($ubah) {
    $baris = jalankan($koneksi, "SELECT * FROM tb_usulan WHERE id_usulan = ?", 'i', [$id]);
    if (!$baris) {
        pesan_set('galat', 'Usulan tidak ditemukan.');
        header('Location: usulan.php');
        exit;
    }
    $data = $baris[0];
    if (!boleh_kecamatan((int)$data['id_kecamatan'])) {
        pesan_set('galat', 'Usulan ini berada di luar kecamatan akun Anda.');
        header('Location: usulan.php');
        exit;
    }
    foreach (jalankan($koneksi, "SELECT id_kriteria, skor FROM tb_usulan_skor WHERE id_usulan = ?", 'i', [$id]) as $s) {
        $skor_tersimpan[(int)$s['id_kriteria']] = (int)$s['skor'];
    }
}

$kriteria      = ambil_kriteria($koneksi);
$kategori      = ambil_kategori($koneksi);
$kecamatan_ref = ambil_kecamatan_pilihan($koneksi);
if (kec_user() > 0) {
    $data['id_kecamatan'] = kec_user();
}
$sumber_ref    = ambil_daftar($koneksi, 'tb_sumber_usulan', 'id_sumber');
$sektor_ref    = ambil_daftar($koneksi, 'tb_sektor', 'id_sektor');
$opd_ref       = ambil_daftar($koneksi, 'tb_opd', 'id_opd');
$panduan       = jalankan($koneksi, "SELECT * FROM tb_panduan_skor ORDER BY skor DESC");
$peta_desa     = ambil_peta_desa($koneksi);

require_once __DIR__ . '/includes/header.php';
?>

<form method="post" action="proses/usulan_simpan.php" class="grid gap-5 lg:grid-cols-3">
  <input type="hidden" name="csrf" value="<?= token_csrf() ?>">
  <input type="hidden" name="id_usulan" value="<?= $ubah ? (int)$id : 0 ?>">

  <div class="lg:col-span-2 space-y-5">

    <div class="kartu p-5">
      <p class="font-semibold text-sm text-slate-800 mb-4">Identitas usulan</p>
      <div class="grid gap-4 md:grid-cols-2">
        <div>
          <label class="block text-xs text-slate-600 mb-1">Kode usulan</label>
          <input class="isian bg-slate-50" value="<?= e($data['kode_usulan']) ?>" disabled>
        </div>
        <div>
          <label class="block text-xs text-slate-600 mb-1">Tahun rencana</label>
          <input type="number" name="tahun" required value="<?= e($data['tahun']) ?>" class="isian">
        </div>
        <div>
          <label class="block text-xs text-slate-600 mb-1">Kecamatan</label>
          <?php if (kec_user() > 0): ?>
            <input type="hidden" name="id_kecamatan" id="f_kec" value="<?= kec_user() ?>">
            <input class="isian bg-slate-50" value="<?= e($_SESSION['nama_kecamatan'] ?? '') ?>" disabled>
          <?php else: ?>
          <select name="id_kecamatan" id="f_kec" required class="isian">
            <option value="">Pilih kecamatan</option>
            <?php foreach ($kecamatan_ref as $r): ?>
              <option value="<?= $r['id_kecamatan'] ?>" <?= $data['id_kecamatan'] == $r['id_kecamatan'] ? 'selected' : '' ?>><?= e($r['nama']) ?></option>
            <?php endforeach; ?>
          </select>
          <?php endif; ?>
        </div>
        <div>
          <label class="block text-xs text-slate-600 mb-1">Desa atau kelurahan</label>
          <select name="desa" id="f_desa" required class="isian" data-terpilih="<?= e($data['desa']) ?>"></select>
          <input name="desa" id="f_desa_teks" required value="<?= e($data['desa']) ?>" class="isian hidden" disabled
                 placeholder="Ketik nama desa">
          <p id="f_desa_info" class="text-xs text-amber-700 mt-1 hidden">
            Daftar desa kecamatan ini belum diisi pada menu Master. Ketik nama desa secara manual.
          </p>
        </div>
        <div>
          <label class="block text-xs text-slate-600 mb-1">Sumber usulan</label>
          <select name="id_sumber" required class="isian">
            <option value="">Pilih sumber</option>
            <?php foreach ($sumber_ref as $r): ?>
              <option value="<?= $r['id_sumber'] ?>" <?= $data['id_sumber'] == $r['id_sumber'] ? 'selected' : '' ?>><?= e($r['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="block text-xs text-slate-600 mb-1">Sektor</label>
          <select name="id_sektor" required class="isian">
            <option value="">Pilih sektor</option>
            <?php foreach ($sektor_ref as $r): ?>
              <option value="<?= $r['id_sektor'] ?>" <?= $data['id_sektor'] == $r['id_sektor'] ? 'selected' : '' ?>><?= e($r['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs text-slate-600 mb-1">OPD penanggung jawab</label>
          <select name="id_opd" required class="isian">
            <option value="">Pilih OPD</option>
            <?php foreach ($opd_ref as $r): ?>
              <option value="<?= $r['id_opd'] ?>" <?= $data['id_opd'] == $r['id_opd'] ? 'selected' : '' ?>><?= e($r['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs text-slate-600 mb-1">Nama usulan kegiatan</label>
          <input name="nama_usulan" required value="<?= e($data['nama_usulan']) ?>" class="isian"
                 placeholder="Contoh: Pembangunan jalan penghubung Dusun II">
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs text-slate-600 mb-1">Uraian masalah dan kondisi eksisting</label>
          <textarea name="uraian_masalah" rows="3" class="isian"
                    placeholder="Tuliskan kondisi lapangan yang menjadi dasar usulan."><?= e($data['uraian_masalah']) ?></textarea>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs text-slate-600 mb-1">Volume</label>
            <input type="number" step="0.01" name="volume" value="<?= e($data['volume']) ?>" class="isian">
          </div>
          <div>
            <label class="block text-xs text-slate-600 mb-1">Satuan</label>
            <input name="satuan" value="<?= e($data['satuan']) ?>" class="isian" placeholder="Meter, Unit, Paket">
          </div>
        </div>
        <div>
          <label class="block text-xs text-slate-600 mb-1">Estimasi anggaran (Rp)</label>
          <input type="number" step="1" name="estimasi_anggaran" value="<?= e($data['estimasi_anggaran']) ?>" class="isian">
        </div>
      </div>
    </div>

    <div class="kartu p-5">
      <div class="flex items-start justify-between mb-1">
        <p class="font-semibold text-sm text-slate-800">Penilaian kriteria</p>
        <a href="panduan.php" class="text-xs" style="color:#0F766E">Panduan pemberian skor</a>
      </div>
      <p class="text-xs text-slate-500 mb-4">
        Skor 1 sampai 5 diisi berdasarkan hasil verifikasi, bukan berdasarkan popularitas usulan.
      </p>

      <div class="space-y-3">
      <?php foreach ($kriteria as $kr): $terpilih = $skor_tersimpan[$kr['id_kriteria']] ?? 3; ?>
        <div class="border border-slate-200 rounded-lg p-3">
          <div class="flex items-start justify-between gap-4">
            <div class="min-w-0">
              <p class="text-sm font-medium text-slate-800"><?= e($kr['nama']) ?>
                <span class="text-xs font-normal text-slate-500">bobot <?= angka($kr['bobot'], 0) ?></span></p>
              <p class="text-xs text-slate-500 mt-0.5"><?= e($kr['deskripsi']) ?></p>
            </div>
            <div class="text-right shrink-0">
              <p class="text-xs text-slate-500">Nilai</p>
              <p class="text-sm font-semibold" data-nilai="<?= $kr['id_kriteria'] ?>">0,00</p>
            </div>
          </div>
          <div class="flex flex-wrap gap-2 mt-3">
            <?php for ($s = 1; $s <= (int)$kr['skala_maks']; $s++): ?>
              <label class="cursor-pointer">
                <input type="radio" class="sr-only skor" name="skor[<?= $kr['id_kriteria'] ?>]"
                       value="<?= $s ?>" data-bobot="<?= $kr['bobot'] ?>" data-skala="<?= $kr['skala_maks'] ?>"
                       data-id="<?= $kr['id_kriteria'] ?>" <?= $terpilih == $s ? 'checked' : '' ?>>
                <span class="pilihan inline-flex items-center justify-center w-9 h-9 rounded-lg border border-slate-300 text-sm"><?= $s ?></span>
              </label>
            <?php endfor; ?>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    </div>

    <?php if (boleh('admin','verifikator')): ?>
    <div class="kartu p-5">
      <p class="font-semibold text-sm text-slate-800 mb-4">Verifikasi</p>
      <div class="grid gap-4 md:grid-cols-3">
        <div>
          <label class="block text-xs text-slate-600 mb-1">Status</label>
          <select name="status" class="isian">
            <?php foreach (['Draft','Terverifikasi','Ditolak'] as $s): ?>
              <option value="<?= $s ?>" <?= $data['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs text-slate-600 mb-1">Catatan verifikasi</label>
          <input name="catatan_verifikasi" value="<?= e($data['catatan_verifikasi']) ?>" class="isian"
                 placeholder="Catatan kewenangan, tata ruang, lahan, atau duplikasi kegiatan">
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>

  <div class="space-y-5">
    <div class="kartu p-5 sticky top-4">
      <p class="font-semibold text-sm text-slate-800 mb-3">Hasil skoring</p>

      <div class="rounded-lg p-4 text-white mb-4" style="background:#0B3B37">
        <p class="text-xs text-slate-300">Nilai akhir</p>
        <p class="text-4xl font-bold" id="totalNilai">0,00</p>
        <p class="text-xs mt-2 inline-block px-2 py-0.5 rounded-full" id="labelKategori" style="background:#0F766E">Belum dinilai</p>
      </div>

      <table class="w-full text-xs mb-4">
        <thead>
          <tr class="text-slate-500 border-b border-slate-200">
            <th class="text-left py-1 font-medium">Kriteria</th>
            <th class="text-right py-1 font-medium">Skor</th>
            <th class="text-right py-1 font-medium">Bobot</th>
            <th class="text-right py-1 font-medium">Nilai</th>
          </tr>
        </thead>
        <tbody id="rincianSkor"></tbody>
      </table>

      <p class="text-xs text-slate-500 leading-relaxed mb-4">
        Nilai tiap kriteria dihitung dengan rumus skor dibagi skala maksimum lalu dikali bobot.
        Nilai akhir adalah penjumlahan seluruh kriteria.
      </p>

      <button class="tombol w-full"><?= $ubah ? 'Simpan perubahan' : 'Simpan usulan' ?></button>
      <a href="usulan.php" class="tombol-2 w-full block text-center mt-2">Batal</a>
    </div>

    <div class="kartu p-5">
      <p class="font-semibold text-sm text-slate-800 mb-3">Arti skor</p>
      <ul class="text-xs text-slate-600 space-y-1">
        <?php foreach ($panduan as $p): ?>
          <li><b><?= (int)$p['skor'] ?></b> &middot; <?= e($p['keterangan']) ?></li>
        <?php endforeach; ?>
      </ul>
      <p class="font-semibold text-sm text-slate-800 mt-4 mb-2">Ambang kategori</p>
      <ul class="text-xs text-slate-600 space-y-1">
        <?php foreach ($kategori as $k): ?>
          <li><span class="lencana" style="background:<?= e($k['warna']) ?>"><?= e($k['nama']) ?></span>
              nilai <?= angka($k['batas_bawah'], 0) ?> ke atas</li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</form>

<style>
  .skor:checked + .pilihan { background:#0F766E; color:#fff; border-color:#0F766E; font-weight:600; }
  .skor:focus-visible + .pilihan { outline:2px solid #0B3B37; outline-offset:2px; }
</style>

<script>
const daftarKategori = <?= json_encode(array_map(function ($k) {
    return ['nama' => $k['nama'], 'batas' => (float)$k['batas_bawah'], 'warna' => $k['warna']];
}, $kategori)) ?>;
const namaKriteria = <?= json_encode(array_map(function ($k) {
    return ['id' => (int)$k['id_kriteria'], 'kode' => $k['kode'], 'nama' => $k['nama']];
}, $kriteria)) ?>;

function angkaID(n) {
  return n.toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function hitung() {
  let total = 0;
  const baris = [];

  namaKriteria.forEach(kr => {
    const dipilih = document.querySelector('input[name="skor[' + kr.id + ']"]:checked');
    if (!dipilih) { return; }
    const skor  = Number(dipilih.value);
    const bobot = Number(dipilih.dataset.bobot);
    const skala = Number(dipilih.dataset.skala) || 5;
    const nilai = Math.round((skor / skala) * bobot * 100) / 100;
    total += nilai;

    const sel = document.querySelector('[data-nilai="' + kr.id + '"]');
    if (sel) { sel.textContent = angkaID(nilai); }

    baris.push('<tr class="border-b border-slate-100">'
      + '<td class="py-1 text-slate-700">' + kr.nama + '</td>'
      + '<td class="py-1 text-right">' + skor + '</td>'
      + '<td class="py-1 text-right">' + angkaID(bobot) + '</td>'
      + '<td class="py-1 text-right font-medium">' + angkaID(nilai) + '</td></tr>');
  });

  total = Math.round(total * 100) / 100;
  document.getElementById('totalNilai').textContent = angkaID(total);
  document.getElementById('rincianSkor').innerHTML = baris.join('');

  const kat = daftarKategori.find(k => total >= k.batas);
  const label = document.getElementById('labelKategori');
  label.textContent = kat ? kat.nama : 'Belum dinilai';
  label.style.background = kat ? kat.warna : '#0F766E';
}

/* Desa mengikuti kecamatan: hanya desa milik kecamatan terpilih yang muncul */
(function () {
  const peta  = <?= json_encode($peta_desa, JSON_UNESCAPED_UNICODE) ?>;
  const kec   = document.getElementById('f_kec');
  const pilih = document.getElementById('f_desa');
  const teks  = document.getElementById('f_desa_teks');
  const info  = document.getElementById('f_desa_info');
  const awal  = pilih.dataset.terpilih || '';

  function isi(pertama) {
    const daftar = peta[kec.value] || [];
    const adaMaster = daftar.length > 0;
    pilih.innerHTML = '';
    const o = document.createElement('option');
    o.value = '';
    o.textContent = kec.value ? 'Pilih desa atau kelurahan' : 'Pilih kecamatan terlebih dahulu';
    pilih.appendChild(o);
    daftar.forEach(function (n) {
      const op = document.createElement('option');
      op.value = n; op.textContent = n;
      if (pertama && n === awal) { op.selected = true; }
      pilih.appendChild(op);
    });
    /* Data lama yang desanya belum ada di master tetap ditampilkan agar tidak hilang */
    if (pertama && awal && adaMaster && daftar.indexOf(awal) === -1) {
      const op = document.createElement('option');
      op.value = awal; op.textContent = awal + ' (belum ada di master)'; op.selected = true;
      pilih.appendChild(op);
    }
    const manual = kec.value && !adaMaster;
    pilih.classList.toggle('hidden', manual);
    pilih.disabled = manual || !kec.value;
    teks.classList.toggle('hidden', !manual);
    teks.disabled = !manual;
    info.classList.toggle('hidden', !manual);
    if (!pertama) { teks.value = ''; }
  }
  if (kec.tagName === 'SELECT') {
    kec.addEventListener('change', function () { isi(false); });
  }
  isi(true);
})();

document.querySelectorAll('.skor').forEach(el => el.addEventListener('change', hitung));
hitung();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
