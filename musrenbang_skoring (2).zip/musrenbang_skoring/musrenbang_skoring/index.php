<?php
/**
 * Halaman publik: dapat dibuka tanpa masuk.
 * Menampilkan usulan yang sudah dinilai (kecuali yang ditolak),
 * diurutkan menurut nilai, per kecamatan dan per desa.
 */
require_once __DIR__ . '/includes/fungsi.php';

$sudah_masuk = !empty($_SESSION['id_user']);

/* ---------------- Penyaring ---------------- */
$daftar_tahun = array_map('intval', array_column(
    jalankan($koneksi, "SELECT DISTINCT tahun FROM tb_usulan ORDER BY tahun DESC"), 'tahun'));
if (!in_array(APP_TAHUN_DEFAULT, $daftar_tahun, true)) { $daftar_tahun[] = APP_TAHUN_DEFAULT; }
rsort($daftar_tahun);

$tahun  = (int)($_GET['tahun'] ?? APP_TAHUN_DEFAULT);
$kec    = (int)($_GET['kec'] ?? 0);
$desa   = $kec > 0 ? trim((string)($_GET['desa'] ?? '')) : '';
$tampil = ($_GET['tampil'] ?? 'kecamatan') === 'desa' ? 'desa' : 'kecamatan';

$ref_kecamatan = ambil_daftar($koneksi, 'tb_kecamatan', 'id_kecamatan');
$nama_kec = '';
foreach ($ref_kecamatan as $r) {
    if ((int)$r['id_kecamatan'] === $kec) { $nama_kec = $r['nama']; }
}
if ($nama_kec === '') { $kec = 0; $desa = ''; }

/* Syarat data publik */
$syarat_publik = "u.tahun = ? AND u.total_nilai IS NOT NULL AND u.status <> 'Ditolak'";

/* Pilihan desa per kecamatan: master desa, dilengkapi desa yang pernah diinput */
$peta_desa = ambil_peta_desa($koneksi);
foreach (jalankan($koneksi, "SELECT DISTINCT id_kecamatan, desa FROM tb_usulan u WHERE $syarat_publik", 'i', [$tahun]) as $r) {
    $ik = (int)$r['id_kecamatan'];
    if (empty($peta_desa[$ik]) || !in_array($r['desa'], $peta_desa[$ik], true)) {
        $peta_desa[$ik][] = $r['desa'];
    }
}
foreach ($peta_desa as &$dd) { sort($dd, SORT_NATURAL | SORT_FLAG_CASE); }
unset($dd);

/* ---------------- Ringkasan kabupaten ---------------- */
$ringkas = jalankan($koneksi, "
    SELECT COUNT(*) AS jumlah,
           COUNT(DISTINCT CONCAT(u.id_kecamatan, '|', u.desa)) AS jml_desa,
           COALESCE(SUM(CASE WHEN u.total_nilai >= 80 THEN 1 ELSE 0 END),0) AS tinggi
    FROM tb_usulan u WHERE $syarat_publik", 'i', [$tahun])[0];

$kategori = ambil_kategori($koneksi);
$kriteria = ambil_kriteria($koneksi);

/* Peringkat kompetisi: nilai sama mendapat nomor sama */
function beri_peringkat(array $baris): array
{
    $nomor = 0;
    $sebelum = null;
    foreach ($baris as $i => $b) {
        if ($sebelum === null || (float)$b['total_nilai'] < (float)$sebelum) {
            $nomor = $i + 1;
            $sebelum = $b['total_nilai'];
        }
        $baris[$i]['peringkat'] = $nomor;
    }
    return $baris;
}

if ($kec > 0) {
    /* Semua usulan kecamatan ini (untuk hitungan per desa) */
    $semua_kec = beri_peringkat(jalankan($koneksi, SQL_USULAN_DASAR . "
        WHERE $syarat_publik AND u.id_kecamatan = ?
        ORDER BY u.total_nilai DESC, u.estimasi_anggaran ASC, u.nama_usulan ASC", 'ii', [$tahun, $kec]));

    $per_desa = [];
    foreach ($peta_desa[$kec] ?? [] as $nd) { $per_desa[$nd] = []; }
    foreach ($semua_kec as $u) { $per_desa[$u['desa']][] = $u; }
    uksort($per_desa, 'strnatcasecmp');

    $daftar = $desa !== ''
        ? array_values(array_filter($semua_kec, function ($u) use ($desa) { return $u['desa'] === $desa; }))
        : $semua_kec;

    $desa_berusulan = count(array_filter($per_desa));
    $anggaran_kec   = array_sum(array_column($daftar, 'estimasi_anggaran'));
    $rata_kec       = $daftar ? array_sum(array_column($daftar, 'total_nilai')) / count($daftar) : 0;
} else {
    $rekap_kec = jalankan($koneksi, "
        SELECT kec.id_kecamatan, kec.nama,
               COUNT(u.id_usulan) AS jumlah,
               COALESCE(MAX(u.total_nilai),0) AS maks,
               COALESCE(SUM(CASE WHEN u.total_nilai >= 80 THEN 1 ELSE 0 END),0) AS tinggi,
               COUNT(DISTINCT u.desa) AS desa_berusulan
        FROM tb_kecamatan kec
        LEFT JOIN tb_usulan u ON u.id_kecamatan = kec.id_kecamatan AND $syarat_publik
        WHERE kec.aktif = 1
        GROUP BY kec.id_kecamatan, kec.nama
        ORDER BY kec.nama", 'i', [$tahun]);
    $maks_jumlah = max(1, (int)max(array_merge([1], array_map('intval', array_column($rekap_kec, 'jumlah')))));

    $teratas = beri_peringkat(jalankan($koneksi, SQL_USULAN_DASAR . "
        WHERE $syarat_publik
        ORDER BY u.total_nilai DESC, u.estimasi_anggaran ASC LIMIT 10", 'i', [$tahun]));
}

/* Tautan dengan penyaring saat ini, sebagian nilainya dapat diganti */
function tautan(array $ubah): string
{
    global $tahun, $kec, $desa, $tampil;
    $q = array_merge([
        'tahun'  => $tahun,
        'kec'    => $kec ?: null,
        'desa'   => $desa !== '' ? $desa : null,
        'tampil' => $tampil === 'desa' ? 'desa' : null,
    ], $ubah);
    $q = array_filter($q, function ($v) { return $v !== null && $v !== ''; });
    return 'index.php?' . http_build_query($q) . '#data';
}

function sel_nilai(array $u): string
{
    $n = (float)$u['total_nilai'];
    $w = max(2, min(100, $n));
    return '<div class="nilai"><span class="angka">' . angka($n) . '</span>'
         . '<span class="batang"><i style="width:' . $w . '%;background:' . e($u['warna_kategori'] ?: '#64748B') . '"></i></span></div>';
}

$warna_bobot = ['#0B3B37', '#0F766E', '#2F8F83', '#4FA99B', '#7DBFB3', '#A9D3CA'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Data prioritas usulan Musrenbang - <?= APP_NAMA ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style>
  :root {
    --tinta:#0B3B37; --laut:#0F766E; --laut-tua:#0B5F58; --pasir:#F6F5F1;
    --kaca:#CFE7E2; --garis:#E3E1DA; --teks:#1C2B29; --redup:#5B6B68; --emas:#E3B448;
  }
  html { scroll-behavior:smooth; }
  @media (prefers-reduced-motion: reduce) { html { scroll-behavior:auto; } }
  body { font-family:"Plus Jakarta Sans", ui-sans-serif, system-ui, "Segoe UI", Arial, sans-serif;
         background:var(--pasir); color:var(--teks); }
  a:focus-visible, button:focus-visible, select:focus-visible { outline:2px solid var(--emas); outline-offset:2px; }

  /* Navbar */
  .nav { background:rgba(11,59,55,.97); backdrop-filter:blur(8px); }
  .nav a.menu { color:#C9DEDA; font-size:.9rem; font-weight:500; padding:.4rem .2rem; border-bottom:2px solid transparent; }
  .nav a.menu:hover { color:#fff; border-bottom-color:var(--kaca); }
  .btn-masuk { background:#fff; color:var(--tinta); font-weight:700; font-size:.875rem;
               padding:.55rem 1.1rem; border-radius:.55rem; white-space:nowrap; }
  .btn-masuk:hover { background:var(--kaca); }

  /* Hero dengan lengkung garis pantai di bawahnya */
  .hero { background:var(--tinta); color:#fff; position:relative; overflow:hidden; }
  .hero::after { content:""; position:absolute; left:-10%; right:-10%; bottom:-1px; height:90px;
                 background:radial-gradient(120% 100% at 50% 100%, var(--pasir) 49%, transparent 50%); }
  .hero h1 { font-weight:800; letter-spacing:-.025em; line-height:1.08; }
  .panel { background:#fff; color:var(--teks); border-radius:1rem; box-shadow:0 24px 48px -24px rgba(0,0,0,.45); }
  .isian { width:100%; border:1px solid #CBD5D1; border-radius:.55rem; padding:.6rem .7rem; font-size:.9rem; background:#fff; }
  .isian:disabled { background:#F1F1EC; color:#8A9794; }
  .tombol { background:var(--laut); color:#fff; font-weight:700; border-radius:.55rem; padding:.65rem 1rem; font-size:.9rem; }
  .tombol:hover { background:var(--laut-tua); }
  .angka-hero { font-size:2rem; font-weight:800; letter-spacing:-.02em; line-height:1; }

  /* Konten */
  .kartu { background:#fff; border:1px solid var(--garis); border-radius:.9rem; }
  table.data { width:100%; border-collapse:collapse; }
  table.data th { text-align:left; font-size:.75rem; font-weight:600; color:var(--redup);
                  padding:.6rem .75rem; border-bottom:1px solid var(--garis); white-space:nowrap; background:#FBFAF7; }
  table.data td { padding:.7rem .75rem; border-bottom:1px solid #EFEDE7; font-size:.875rem; vertical-align:top; }
  table.data tbody tr:last-child td { border-bottom:0; }
  .rank { display:inline-flex; align-items:center; justify-content:center; width:2rem; height:2rem;
          border-radius:.5rem; background:#EEF5F3; color:var(--tinta); font-weight:800; font-size:.85rem; }
  .rank.r1 { background:var(--emas); color:#3A2B05; }
  .rank.r2, .rank.r3 { background:var(--kaca); }
  .lencana { display:inline-block; padding:.15rem .55rem; border-radius:999px; font-size:.72rem; font-weight:600; color:#fff; white-space:nowrap; }
  .sektor { display:inline-flex; align-items:center; gap:.35rem; font-size:.8rem; color:var(--redup); white-space:nowrap; }
  .sektor i { width:.55rem; height:.55rem; border-radius:2px; display:inline-block; }
  .nilai { min-width:100px; }
  .nilai .angka { font-weight:800; font-size:1rem; }
  .nilai .batang { display:block; height:5px; background:#EDEBE5; border-radius:3px; margin-top:.3rem; overflow:hidden; }
  .nilai .batang i { display:block; height:100%; border-radius:3px; }

  .chip { display:inline-flex; align-items:center; gap:.4rem; padding:.35rem .75rem; border-radius:999px;
          border:1px solid var(--garis); background:#fff; font-size:.8rem; color:var(--teks); }
  .chip b { font-weight:700; color:var(--laut); }
  .chip:hover { border-color:var(--laut); }
  .chip.kosong { color:#9AA5A2; }
  .chip.kosong b { color:#B5BDBA; }
  .chip.aktif { background:var(--tinta); border-color:var(--tinta); color:#fff; }
  .chip.aktif b { color:var(--kaca); }
  .saklar a { display:inline-block; padding:.45rem .9rem; font-size:.85rem; font-weight:600; color:var(--redup); border-radius:.45rem; }
  .saklar a.aktif { background:#fff; color:var(--tinta); box-shadow:0 1px 2px rgba(0,0,0,.08); }

  .baris-kec { display:grid; grid-template-columns:minmax(150px,1.3fr) 1.4fr 80px 110px 20px; gap:1rem; align-items:center;
               padding:.8rem 1.1rem; border-bottom:1px solid #EFEDE7; }
  a.baris-kec:hover { background:#F4FAF8; }
  .baris-kec .isi { height:8px; border-radius:4px; background:#EDEBE5; overflow:hidden; display:flex; }
  @media (max-width: 640px) {
    .baris-kec { grid-template-columns:1fr 60px 16px; }
    .baris-kec .sembunyi-hp { display:none; }
  }

  /* Bobot kriteria sebagai satu batang bernilai 100 */
  .bobot { display:flex; height:60px; border-radius:.7rem; overflow:hidden; }
  .bobot div { display:flex; flex-direction:column; justify-content:center; padding:0 .7rem; color:#fff; min-width:0; }
  .bobot div b { font-size:1.15rem; font-weight:800; line-height:1; }
  .bobot div span { font-size:.72rem; opacity:.9; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:.2rem; }

  @media print {
    .nav, .hero, #penilaian, footer, .cetak-sembunyi { display:none !important; }
    main { margin-top:0 !important; }
  }
</style>
</head>
<body>

<header class="nav sticky top-0 z-30">
  <div class="max-w-6xl mx-auto px-5 h-16 flex items-center gap-6">
    <a href="index.php" class="flex items-center gap-3 shrink-0">
      <svg width="34" height="34" viewBox="0 0 34 34" aria-hidden="true">
        <rect width="34" height="34" rx="9" fill="#0F766E"/>
        <rect x="8"  y="18" width="4" height="8"  rx="1" fill="#CFE7E2"/>
        <rect x="15" y="13" width="4" height="13" rx="1" fill="#CFE7E2"/>
        <rect x="22" y="8"  width="4" height="18" rx="1" fill="#E3B448"/>
      </svg>
      <span class="leading-tight">
        <span class="block text-white font-bold text-[15px]"><?= APP_NAMA ?></span>
        <span class="hidden sm:block text-[11px]" style="color:#9CC3BC"><?= APP_INSTANSI ?></span>
      </span>
    </a>

    <nav class="hidden md:flex items-center gap-6 ml-4" aria-label="Menu utama">
      <a class="menu" href="#beranda">Beranda</a>
      <a class="menu" href="#data">Data prioritas</a>
      <a class="menu" href="#penilaian">Cara penilaian</a>
    </nav>

    <div class="ml-auto flex items-center gap-3">
      <?php if ($sudah_masuk): ?>
        <span class="hidden lg:block text-xs text-right" style="color:#9CC3BC"><?= e($_SESSION['nama_lengkap'] ?? '') ?></span>
        <a href="dashboard.php" class="btn-masuk">Buka dashboard</a>
      <?php else: ?>
        <a href="login.php" class="btn-masuk">Masuk</a>
      <?php endif; ?>
      <button type="button" id="tombolMenu" class="md:hidden text-white p-2 -mr-2" aria-expanded="false" aria-controls="menuHp" aria-label="Buka menu">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
    </div>
  </div>
  <nav id="menuHp" class="md:hidden hidden border-t border-white/10 px-5 py-3 space-y-2" aria-label="Menu ponsel">
    <a class="menu block" href="#beranda">Beranda</a>
    <a class="menu block" href="#data">Data prioritas</a>
    <a class="menu block" href="#penilaian">Cara penilaian</a>
  </nav>
</header>

<section id="beranda" class="hero">
  <div class="max-w-6xl mx-auto px-5 pt-14 pb-28 grid gap-10 lg:grid-cols-12 items-start relative z-10">
    <div class="lg:col-span-7">
      <p class="text-sm font-medium mb-4" style="color:#9CC3BC">Musrenbang Kabupaten Banggai, tahun rencana <?= $tahun ?></p>
      <h1 class="text-4xl md:text-5xl">Usulan pembangunan dari setiap desa, diurutkan menurut nilai prioritas.</h1>
      <p class="mt-5 text-base leading-relaxed max-w-xl" style="color:#C9DEDA">
        Setiap usulan dinilai dengan enam kriteria berbobot. Pilih kecamatan untuk melihat urutan usulannya,
        lalu pilih desa bila ingin melihat satu desa saja.
      </p>

      <dl class="mt-9 grid grid-cols-3 gap-6 max-w-lg">
        <div>
          <dt class="text-xs" style="color:#9CC3BC">Usulan dinilai</dt>
          <dd class="angka-hero mt-1"><?= number_format($ringkas['jumlah'], 0, ',', '.') ?></dd>
        </div>
        <div>
          <dt class="text-xs" style="color:#9CC3BC">Desa pengusul</dt>
          <dd class="angka-hero mt-1"><?= number_format($ringkas['jml_desa'], 0, ',', '.') ?></dd>
        </div>
        <div>
          <dt class="text-xs" style="color:#9CC3BC">Nilai 80 ke atas</dt>
          <dd class="angka-hero mt-1" style="color:var(--emas)"><?= number_format($ringkas['tinggi'], 0, ',', '.') ?></dd>
        </div>
      </dl>
    </div>

    <form method="get" action="index.php#data" class="panel p-6 lg:col-span-5">
      <p class="font-bold text-lg">Lihat data prioritas</p>
      <p class="text-sm mt-1 mb-5" style="color:var(--redup)">Daftar desa menyesuaikan kecamatan yang dipilih.</p>

      <label for="f_tahun" class="block text-xs font-semibold mb-1" style="color:var(--redup)">Tahun rencana</label>
      <select id="f_tahun" name="tahun" class="isian mb-4">
        <?php foreach ($daftar_tahun as $t): ?>
          <option value="<?= $t ?>" <?= $t === $tahun ? 'selected' : '' ?>><?= $t ?></option>
        <?php endforeach; ?>
      </select>

      <label for="f_kec" class="block text-xs font-semibold mb-1" style="color:var(--redup)">Kecamatan</label>
      <select id="f_kec" name="kec" class="isian mb-4">
        <option value="0">Semua kecamatan</option>
        <?php foreach ($ref_kecamatan as $r): ?>
          <option value="<?= $r['id_kecamatan'] ?>" <?= $kec === (int)$r['id_kecamatan'] ? 'selected' : '' ?>><?= e($r['nama']) ?></option>
        <?php endforeach; ?>
      </select>

      <label for="f_desa" class="block text-xs font-semibold mb-1" style="color:var(--redup)">Desa/kelurahan</label>
      <select id="f_desa" name="desa" class="isian mb-5" data-terpilih="<?= e($desa) ?>"></select>

      <?php if ($tampil === 'desa'): ?><input type="hidden" name="tampil" value="desa"><?php endif; ?>
      <button class="tombol w-full">Tampilkan data</button>
    </form>
  </div>
</section>

<main id="data" class="max-w-6xl mx-auto px-5 -mt-6 pb-16 relative z-10 scroll-mt-20">

<?php if ($kec === 0): ?>

  <h2 class="text-2xl font-extrabold tracking-tight">Rekap per kecamatan</h2>
  <p class="text-sm mt-1 mb-4" style="color:var(--redup)">Pilih satu kecamatan untuk melihat urutan usulan di seluruh desanya.</p>

  <div class="kartu overflow-hidden mb-12">
    <div class="baris-kec text-xs font-semibold" style="color:var(--redup);background:#FBFAF7">
      <span>Kecamatan</span>
      <span class="sembunyi-hp">Sebaran usulan (warna tua: nilai 80 ke atas)</span>
      <span class="text-right">Usulan</span>
      <span class="text-right sembunyi-hp">Nilai tertinggi</span>
      <span></span>
    </div>
    <?php foreach ($rekap_kec as $r):
        $j = (int)$r['jumlah'];
        $t = (int)$r['tinggi'];
        $lebar_t = $t / $maks_jumlah * 100;
        $lebar_s = ($j - $t) / $maks_jumlah * 100; ?>
      <a class="baris-kec" href="index.php?tahun=<?= $tahun ?>&amp;kec=<?= (int)$r['id_kecamatan'] ?>#data">
        <span>
          <span class="font-semibold"><?= e($r['nama']) ?></span>
          <span class="block text-xs" style="color:var(--redup)"><?= $j ? (int)$r['desa_berusulan'] . ' desa mengusulkan' : 'Belum ada usulan dinilai' ?></span>
        </span>
        <span class="isi sembunyi-hp" title="<?= $t ?> dari <?= $j ?> usulan bernilai 80 ke atas">
          <i style="width:<?= $lebar_t ?>%;background:var(--tinta)"></i>
          <i style="width:<?= $lebar_s ?>%;background:#8FC4BA"></i>
        </span>
        <span class="text-right font-bold <?= $j ? '' : 'text-slate-400' ?>"><?= $j ?></span>
        <span class="text-right sembunyi-hp"><?= $j ? angka($r['maks']) : '<span style="color:#B5BDBA">-</span>' ?></span>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8A9794" stroke-width="2" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
      </a>
    <?php endforeach; ?>
  </div>

  <h2 class="text-2xl font-extrabold tracking-tight">Sepuluh usulan bernilai tertinggi se-kabupaten</h2>
  <p class="text-sm mt-1 mb-4" style="color:var(--redup)">Tahun rencana <?= $tahun ?>.</p>
  <div class="kartu overflow-x-auto">
    <table class="data">
      <thead><tr><th>Peringkat</th><th>Usulan</th><th>Lokasi</th><th>Sektor</th><th class="text-right">Estimasi anggaran</th><th>Nilai</th><th>Kategori</th></tr></thead>
      <tbody>
      <?php foreach ($teratas as $u): $p = (int)$u['peringkat']; ?>
        <tr>
          <td><span class="rank <?= $p <= 3 ? 'r' . $p : '' ?>"><?= $p ?></span></td>
          <td class="font-semibold"><?= e($u['nama_usulan']) ?></td>
          <td><?= e($u['desa']) ?><div class="text-xs" style="color:var(--redup)">Kec. <?= e($u['kecamatan']) ?></div></td>
          <td><span class="sektor"><i style="background:<?= e($u['warna_sektor']) ?>"></i><?= e($u['sektor']) ?></span></td>
          <td class="text-right whitespace-nowrap"><?= rupiah($u['estimasi_anggaran']) ?></td>
          <td><?= sel_nilai($u) ?></td>
          <td><span class="lencana" style="background:<?= e($u['warna_kategori'] ?: '#64748B') ?>"><?= e($u['kategori'] ?: '-') ?></span></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$teratas): ?>
        <tr><td colspan="7" class="text-center py-10" style="color:var(--redup)">
          Belum ada usulan yang dinilai untuk tahun <?= $tahun ?>. Pilih tahun rencana lain pada panel di atas.
        </td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

<?php else: ?>

  <div class="kartu p-5 md:p-6 mb-5">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div>
        <a href="index.php?tahun=<?= $tahun ?>#data" class="text-sm font-semibold cetak-sembunyi" style="color:var(--laut)">Kembali ke semua kecamatan</a>
        <h2 class="text-3xl font-extrabold tracking-tight mt-2">Kecamatan <?= e($nama_kec) ?></h2>
        <p class="text-sm mt-1" style="color:var(--redup)">
          <?php if ($desa !== ''): ?>
            Desa <?= e($desa) ?>, tahun rencana <?= $tahun ?>
          <?php else: ?>
            <?= count($per_desa) ?> desa/kelurahan, <?= $desa_berusulan ?> di antaranya memiliki usulan dinilai. Tahun rencana <?= $tahun ?>.
          <?php endif; ?>
        </p>
      </div>
      <dl class="flex gap-8">
        <div><dt class="text-xs" style="color:var(--redup)">Usulan</dt><dd class="text-2xl font-extrabold"><?= count($daftar) ?></dd></div>
        <div><dt class="text-xs" style="color:var(--redup)">Rata-rata nilai</dt><dd class="text-2xl font-extrabold"><?= angka($rata_kec) ?></dd></div>
        <div class="hidden sm:block"><dt class="text-xs" style="color:var(--redup)">Estimasi anggaran</dt><dd class="text-2xl font-extrabold"><?= rupiah($anggaran_kec) ?></dd></div>
      </dl>
    </div>

    <?php if ($per_desa): ?>
    <div class="mt-5 pt-5 border-t cetak-sembunyi" style="border-color:var(--garis)">
      <p class="text-xs font-semibold mb-2" style="color:var(--redup)">Pilih desa</p>
      <div class="flex flex-wrap gap-2">
        <a href="<?= e(tautan(['desa' => null])) ?>" class="chip <?= $desa === '' ? 'aktif' : '' ?>">Semua desa <b><?= count($semua_kec) ?></b></a>
        <?php foreach ($per_desa as $nd => $isi): $nd = (string)$nd; ?>
          <a href="<?= e(tautan(['desa' => $nd])) ?>"
             class="chip <?= $desa === $nd ? 'aktif' : '' ?> <?= !$isi ? 'kosong' : '' ?>"><?= e($nd) ?> <b><?= count($isi) ?></b></a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($desa === ''): ?>
  <div class="flex flex-wrap items-center justify-between gap-3 mb-3 cetak-sembunyi">
    <div class="saklar inline-flex p-1 rounded-lg" style="background:#ECEAE3">
      <a href="<?= e(tautan(['tampil' => null])) ?>" class="<?= $tampil === 'kecamatan' ? 'aktif' : '' ?>" aria-current="<?= $tampil === 'kecamatan' ? 'true' : 'false' ?>">Peringkat kecamatan</a>
      <a href="<?= e(tautan(['tampil' => 'desa'])) ?>" class="<?= $tampil === 'desa' ? 'aktif' : '' ?>" aria-current="<?= $tampil === 'desa' ? 'true' : 'false' ?>">Dikelompokkan per desa</a>
    </div>
    <button type="button" onclick="window.print()" class="text-sm font-semibold" style="color:var(--laut)">Cetak halaman</button>
  </div>
  <?php endif; ?>

  <?php if ($desa !== '' || $tampil === 'kecamatan'): ?>

    <div class="kartu overflow-x-auto">
      <table class="data">
        <thead><tr>
          <th>Peringkat</th><th>Usulan</th>
          <?php if ($desa === ''): ?><th>Desa/kelurahan</th><?php endif; ?>
          <th>Sektor</th><th>Volume</th><th class="text-right">Estimasi anggaran</th><th>Nilai</th><th>Kategori</th>
        </tr></thead>
        <tbody>
        <?php foreach ($daftar as $u): $p = (int)$u['peringkat']; ?>
          <tr>
            <td><span class="rank <?= $p <= 3 ? 'r' . $p : '' ?>"><?= $p ?></span></td>
            <td>
              <span class="font-semibold"><?= e($u['nama_usulan']) ?></span>
              <?php if ($u['uraian_masalah']): ?>
                <div class="text-xs mt-0.5 max-w-sm" style="color:var(--redup)"><?= e(mb_strimwidth((string)$u['uraian_masalah'], 0, 90, '...')) ?></div>
              <?php endif; ?>
            </td>
            <?php if ($desa === ''): ?><td><?= e($u['desa']) ?></td><?php endif; ?>
            <td><span class="sektor"><i style="background:<?= e($u['warna_sektor']) ?>"></i><?= e($u['sektor']) ?></span></td>
            <td class="whitespace-nowrap"><?= angka($u['volume'], 0) ?> <?= e($u['satuan']) ?></td>
            <td class="text-right whitespace-nowrap"><?= rupiah($u['estimasi_anggaran']) ?></td>
            <td><?= sel_nilai($u) ?></td>
            <td><span class="lencana" style="background:<?= e($u['warna_kategori'] ?: '#64748B') ?>"><?= e($u['kategori'] ?: '-') ?></span></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$daftar): ?>
          <tr><td colspan="8" class="text-center py-10" style="color:var(--redup)">
            <?= $desa !== ''
                ? 'Desa ' . e($desa) . ' belum memiliki usulan yang dinilai pada tahun ' . $tahun . '.'
                : 'Kecamatan ini belum memiliki usulan yang dinilai pada tahun ' . $tahun . '.' ?>
          </td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if ($desa !== '' && $daftar): ?>
      <p class="text-xs mt-2" style="color:var(--redup)">Angka peringkat menunjukkan posisi usulan di antara seluruh usulan Kecamatan <?= e($nama_kec) ?>.</p>
    <?php endif; ?>

  <?php else: ?>

    <div class="grid gap-4 md:grid-cols-2">
    <?php foreach ($per_desa as $nd => $isi): $nd = (string)$nd; ?>
      <section class="kartu overflow-hidden">
        <div class="px-4 py-3 flex items-center justify-between border-b" style="border-color:var(--garis)">
          <h3 class="font-bold <?= $isi ? '' : 'text-slate-400' ?>"><?= e($nd) ?></h3>
          <a href="<?= e(tautan(['desa' => $nd])) ?>" class="text-xs font-semibold" style="color:var(--laut)"><?= count($isi) ?> usulan</a>
        </div>
        <?php if ($isi): ?>
          <table class="data">
            <tbody>
            <?php foreach (array_slice($isi, 0, 5) as $i => $u): ?>
              <tr>
                <td style="width:48px"><span class="rank <?= $i === 0 ? 'r1' : '' ?>"><?= $i + 1 ?></span></td>
                <td><span class="font-semibold"><?= e($u['nama_usulan']) ?></span>
                    <div class="text-xs" style="color:var(--redup)"><?= e($u['sektor']) ?>, peringkat <?= (int)$u['peringkat'] ?> di kecamatan</div></td>
                <td style="width:120px"><?= sel_nilai($u) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php if (count($isi) > 5): ?>
            <a href="<?= e(tautan(['desa' => $nd])) ?>" class="block px-4 py-2 text-xs font-semibold border-t" style="color:var(--laut);border-color:var(--garis)">Lihat <?= count($isi) - 5 ?> usulan lainnya</a>
          <?php endif; ?>
        <?php else: ?>
          <p class="px-4 py-4 text-sm" style="color:var(--redup)">Belum ada usulan yang dinilai.</p>
        <?php endif; ?>
      </section>
    <?php endforeach; ?>
    <?php if (!$per_desa): ?>
      <p class="kartu p-8 text-center md:col-span-2" style="color:var(--redup)">Kecamatan ini belum memiliki data desa maupun usulan.</p>
    <?php endif; ?>
    </div>

  <?php endif; ?>
<?php endif; ?>

  <p class="text-xs mt-6 max-w-3xl" style="color:var(--redup)">
    Halaman ini hanya memuat usulan yang sudah diberi skor dan tidak berstatus ditolak.
    Usulan bernilai sama mendapat peringkat yang sama; di antara nilai yang sama, anggaran lebih kecil ditampilkan lebih dulu.
  </p>
</main>

<section id="penilaian" class="bg-white border-t scroll-mt-16" style="border-color:var(--garis)">
  <div class="max-w-6xl mx-auto px-5 py-14 grid gap-10 lg:grid-cols-12">
    <div class="lg:col-span-4">
      <h2 class="text-2xl font-extrabold tracking-tight">Cara nilai dihitung</h2>
      <p class="mt-3 text-[15px] leading-relaxed" style="color:var(--redup)">
        Verifikator memberi skor 1 sampai 5 pada setiap kriteria. Skor dibagi skala maksimum, lalu dikali bobot kriteria.
        Jumlah seluruh kriteria menjadi nilai akhir berskala 0 sampai 100.
      </p>
    </div>
    <div class="lg:col-span-8">
      <div class="bobot" role="img" aria-label="Pembagian bobot kriteria penilaian">
        <?php foreach ($kriteria as $i => $k): ?>
          <div style="width:<?= (float)$k['bobot'] ?>%;background:<?= $warna_bobot[$i % 6] ?>;<?= $i % 6 >= 4 ? 'color:#0B3B37' : '' ?>"
               title="<?= e($k['nama']) ?>: bobot <?= angka($k['bobot'], 0) ?>">
            <b><?= angka($k['bobot'], 0) ?></b><span><?= e($k['nama']) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
      <ul class="mt-6 grid gap-x-8 gap-y-4 sm:grid-cols-2">
        <?php foreach ($kriteria as $i => $k): ?>
          <li class="flex gap-3">
            <span class="mt-1.5 w-2.5 h-2.5 rounded-sm shrink-0" style="background:<?= $warna_bobot[$i % 6] ?>"></span>
            <span class="text-sm"><b><?= e($k['nama']) ?>, bobot <?= angka($k['bobot'], 0) ?></b>
              <span class="block mt-0.5" style="color:var(--redup)"><?= e($k['deskripsi']) ?></span></span>
          </li>
        <?php endforeach; ?>
      </ul>

      <h3 class="font-bold mt-10 mb-3">Kategori prioritas</h3>
      <div class="flex flex-wrap gap-2">
        <?php foreach ($kategori as $k): ?>
          <span class="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg border" style="border-color:var(--garis)">
            <span class="w-2.5 h-2.5 rounded-full" style="background:<?= e($k['warna']) ?>"></span>
            <?= e($k['nama']) ?>
            <span style="color:var(--redup)"><?= (float)$k['batas_bawah'] > 0 ? 'nilai ' . angka($k['batas_bawah'], 0) . ' ke atas' : 'di bawah ambang' ?></span>
          </span>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<footer style="background:var(--tinta)">
  <div class="max-w-6xl mx-auto px-5 py-8 flex flex-wrap items-center justify-between gap-4 text-sm" style="color:#9CC3BC">
    <p><span class="text-white font-semibold"><?= APP_NAMA ?></span>, <?= APP_SUBJUDUL ?>. <?= APP_INSTANSI ?>.</p>
    <a href="<?= $sudah_masuk ? 'dashboard.php' : 'login.php' ?>" class="text-white font-semibold"><?= $sudah_masuk ? 'Buka dashboard' : 'Masuk untuk petugas' ?></a>
  </div>
</footer>

<script>
(function () {
  /* Desa mengikuti kecamatan: hanya desa milik kecamatan terpilih yang muncul */
  const peta = <?= json_encode($peta_desa, JSON_UNESCAPED_UNICODE) ?>;
  const kec  = document.getElementById('f_kec');
  const desa = document.getElementById('f_desa');
  const awal = desa.dataset.terpilih || '';
  function isi(pertama) {
    const daftar = peta[kec.value] || [];
    desa.innerHTML = '';
    const o = document.createElement('option');
    o.value = '';
    o.textContent = kec.value !== '0'
      ? (daftar.length ? 'Semua desa di kecamatan ini' : 'Belum ada data desa')
      : 'Pilih kecamatan terlebih dahulu';
    desa.appendChild(o);
    daftar.forEach(function (n) {
      const op = document.createElement('option');
      op.value = n;
      op.textContent = n;
      if (pertama && n === awal) { op.selected = true; }
      desa.appendChild(op);
    });
    desa.disabled = kec.value === '0' || !daftar.length;
  }
  kec.addEventListener('change', function () { isi(false); });
  isi(true);

  /* Menu ponsel */
  const tombol = document.getElementById('tombolMenu');
  const menu = document.getElementById('menuHp');
  tombol.addEventListener('click', function () {
    const terbuka = !menu.classList.toggle('hidden');
    tombol.setAttribute('aria-expanded', terbuka ? 'true' : 'false');
  });
  menu.querySelectorAll('a').forEach(function (a) {
    a.addEventListener('click', function () {
      menu.classList.add('hidden');
      tombol.setAttribute('aria-expanded', 'false');
    });
  });
})();
</script>
</body>
</html>
