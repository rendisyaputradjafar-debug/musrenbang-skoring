    </div>
    <footer class="px-6 py-4 text-xs text-slate-500 border-t border-slate-200 cetak-sembunyi">
      <?= APP_NAMA ?> &middot; <?= APP_INSTANSI ?> &middot; Rumus nilai: (skor &divide; skala maksimum) &times; bobot kriteria
    </footer>
  </main>
</div>
</body>
</html>
