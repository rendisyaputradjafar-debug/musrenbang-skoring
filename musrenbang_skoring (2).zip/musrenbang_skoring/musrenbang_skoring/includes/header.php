<?php
require_once __DIR__ . '/fungsi.php';
wajib_login();

$halaman_aktif = $halaman_aktif ?? '';
$judul_halaman = $judul_halaman ?? 'Dashboard';

$menu = [
    ['kunci' => 'dashboard', 'label' => 'Dashboard',        'url' => 'dashboard.php',   'peran' => ['admin','verifikator','operator']],
    ['kunci' => 'usulan',    'label' => 'Daftar usulan',    'url' => 'usulan.php',      'peran' => ['admin','verifikator','operator']],
    ['kunci' => 'input',     'label' => 'Input usulan',     'url' => 'usulan_form.php', 'peran' => ['admin','verifikator','operator']],
    ['kunci' => 'ranking',   'label' => 'Peringkat',        'url' => 'ranking.php',     'peran' => ['admin','verifikator','operator']],
    ['kunci' => 'impor',     'label' => 'Impor dari Excel', 'url' => 'impor.php',       'peran' => ['admin','verifikator']],
    ['kunci' => 'bobot',     'label' => 'Bobot kriteria',   'url' => 'bobot.php',       'peran' => ['admin']],
    ['kunci' => 'master',    'label' => 'Master',           'url' => 'master.php',      'peran' => ['admin']],
    ['kunci' => 'pengguna',  'label' => 'User',             'url' => 'pengguna.php',    'peran' => ['admin']],
    ['kunci' => 'log',       'label' => 'Jejak aktivitas',  'url' => 'log.php',         'peran' => ['admin']],
    ['kunci' => 'panduan',   'label' => 'Panduan',          'url' => 'panduan.php',     'peran' => ['admin','verifikator','operator']],
    ['kunci' => 'publik',    'label' => 'Halaman publik',   'url' => 'index.php',       'peran' => ['admin','verifikator','operator']],
];
$pesan = pesan_ambil();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul_halaman) ?> &middot; <?= APP_NAMA ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
  :root { --tinta:#0B3B37; --laut:#0F766E; --pasir:#F6F5F1; }
  body { font-family: ui-sans-serif, system-ui, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
         background: var(--pasir); color:#111827; }
  .sisi { background: var(--tinta); }
  .sisi a { display:block; padding:.55rem .9rem; border-radius:.5rem; color:#CBD5E1; font-size:.875rem; }
  .sisi a:hover { background: rgba(255,255,255,.08); color:#fff; }
  .sisi a.aktif { background: var(--laut); color:#fff; font-weight:600; }
  .kartu { background:#fff; border:1px solid #E5E7EB; border-radius:.75rem; }
  table.data th { background:#F1F5F9; font-size:.75rem; text-transform:none; font-weight:600;
                  color:#334155; text-align:left; padding:.5rem .65rem; border-bottom:1px solid #E2E8F0; white-space:nowrap; }
  table.data td { padding:.5rem .65rem; border-bottom:1px solid #F1F5F9; font-size:.8125rem; vertical-align:top; }
  table.data tbody tr:hover { background:#F8FAFC; }
  .lencana { display:inline-block; padding:.1rem .5rem; border-radius:999px; font-size:.7rem; font-weight:600; color:#fff; }
  input, select, textarea { background:#fff; }
  .isian { width:100%; border:1px solid #CBD5E1; border-radius:.5rem; padding:.5rem .65rem; font-size:.875rem; }
  .isian:focus { outline:2px solid #0F766E; outline-offset:1px; border-color:#0F766E; }
  .tombol { background:var(--laut); color:#fff; padding:.55rem 1rem; border-radius:.5rem; font-size:.875rem; font-weight:600; }
  .tombol:hover { background:#0B5F58; }
  .tombol-2 { background:#fff; border:1px solid #CBD5E1; color:#334155; padding:.5rem .9rem; border-radius:.5rem; font-size:.875rem; }
  .tombol-2:hover { background:#F1F5F9; }
  .kunci-kec { display:inline-block; background:#E6F2F0; color:#0B3B37; border-radius:.4rem; padding:.15rem .5rem; font-size:.75rem; font-weight:600; }
  @media print { .sisi, .cetak-sembunyi { display:none !important; } main { padding:0 !important; } }
</style>
<script>
/**
 * Menghubungkan pilihan kecamatan dengan pilihan desa.
 * peta: { id_kecamatan: ["Desa A", "Desa B"] }
 * Hanya desa milik kecamatan terpilih yang ditampilkan.
 */
function pasangDesa(idKec, idDesa, peta, labelKosong, labelTanpaKec) {
  const kec = document.getElementById(idKec);
  const desa = document.getElementById(idDesa);
  if (!kec || !desa) { return; }
  const awal = desa.dataset.terpilih || '';
  function isi() {
    const daftar = peta[kec.value] || [];
    desa.innerHTML = '';
    const o = document.createElement('option');
    o.value = '';
    o.textContent = kec.value && kec.value !== '0' ? labelKosong : labelTanpaKec;
    desa.appendChild(o);
    daftar.forEach(function (n) {
      const op = document.createElement('option');
      op.value = n; op.textContent = n;
      if (n === awal) { op.selected = true; }
      desa.appendChild(op);
    });
    desa.disabled = !(kec.value && kec.value !== '0');
  }
  kec.addEventListener('change', function () { desa.dataset.terpilih = ''; isi(); });
  isi();
}
</script>
</head>
<body>
<div class="flex min-h-screen">

  <aside class="sisi w-60 shrink-0 p-4 hidden md:block">
    <div class="mb-6">
      <p class="text-white font-bold text-lg leading-tight"><?= APP_NAMA ?></p>
      <p class="text-slate-400 text-xs mt-1 leading-snug"><?= APP_INSTANSI ?></p>
    </div>
    <nav class="space-y-1">
      <?php foreach ($menu as $m): if (!boleh(...$m['peran'])) continue; ?>
        <a href="<?= $m['url'] ?>" class="<?= $halaman_aktif === $m['kunci'] ? 'aktif' : '' ?>"><?= $m['label'] ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="mt-8 pt-4 border-t border-white/10">
      <p class="text-slate-300 text-xs"><?= e($_SESSION['nama_lengkap']) ?></p>
      <p class="text-slate-500 text-xs capitalize"><?= e($_SESSION['role']) ?></p>
      <?php if (!empty($_SESSION['nama_kecamatan'])): ?>
        <p class="text-xs mt-1" style="color:#5EEAD4">Kec. <?= e($_SESSION['nama_kecamatan']) ?></p>
      <?php endif; ?>
      <div class="mb-2"></div>
      <a href="logout.php" class="text-xs text-slate-300">Keluar</a>
    </div>
  </aside>

  <main class="flex-1 min-w-0">
    <header class="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between cetak-sembunyi">
      <div>
        <h1 class="text-base font-semibold text-slate-900"><?= e($judul_halaman) ?></h1>
        <p class="text-xs text-slate-500"><?= APP_SUBJUDUL ?></p>
      </div>
      <div class="flex items-center gap-4">
      <?php if (kec_user() > 0): ?>
        <span class="kunci-kec">Kecamatan <?= e($_SESSION['nama_kecamatan'] ?? '') ?></span>
      <?php endif; ?>
      <div class="text-right">
        <p class="text-xs text-slate-500">Tahun rencana</p>
        <p class="text-sm font-semibold text-slate-800"><?= e($_GET['tahun'] ?? APP_TAHUN_DEFAULT) ?></p>
      </div>
      </div>
    </header>

    <div class="p-6">
    <?php if ($pesan): ?>
      <div class="mb-4 rounded-lg px-4 py-3 text-sm <?=
        $pesan['jenis'] === 'sukses' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
        : ($pesan['jenis'] === 'galat' ? 'bg-rose-50 text-rose-800 border border-rose-200'
        : 'bg-amber-50 text-amber-800 border border-amber-200') ?>">
        <?= e($pesan['teks']) ?>
      </div>
    <?php endif; ?>
