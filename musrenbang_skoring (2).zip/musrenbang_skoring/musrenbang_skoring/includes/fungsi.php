<?php
/**
 * Fungsi bantu aplikasi.
 * Inti perhitungan skor ada pada hitung_total_nilai() dan tentukan_kategori().
 */

require_once __DIR__ . '/../config/koneksi.php';

/* ------------------------------------------------------------------ */
/* Keamanan sesi                                                       */
/* ------------------------------------------------------------------ */

function wajib_login()
{
    if (empty($_SESSION['id_user'])) {
        header('Location: login.php');
        exit;
    }
}

function peran(): string
{
    return $_SESSION['role'] ?? 'operator';
}

function boleh(string ...$peran_diizinkan): bool
{
    return in_array(peran(), $peran_diizinkan, true);
}

function wajib_peran(string ...$peran_diizinkan)
{
    if (!boleh(...$peran_diizinkan)) {
        http_response_code(403);
        die('<p style="font-family:system-ui;padding:32px">Akun Anda tidak berwenang membuka halaman ini.</p>');
    }
}

/**
 * Kecamatan penugasan akun yang sedang masuk.
 * Nilai 0 berarti akun tidak terikat kecamatan (admin/verifikator kabupaten).
 */
function kec_user(): int
{
    return (int)($_SESSION['id_kecamatan'] ?? 0);
}

/**
 * Apakah akun boleh melihat atau mengubah usulan pada kecamatan tertentu.
 */
function boleh_kecamatan(int $id_kecamatan): bool
{
    return kec_user() === 0 || kec_user() === $id_kecamatan;
}

function token_csrf(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf'];
}

function periksa_csrf()
{
    $kiriman = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $kiriman)) {
        die('<p style="font-family:system-ui;padding:32px">Permintaan ditolak. Muat ulang halaman lalu ulangi.</p>');
    }
}

/* ------------------------------------------------------------------ */
/* Format keluaran                                                     */
/* ------------------------------------------------------------------ */

function e($teks): string
{
    return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
}

function rupiah($angka): string
{
    return 'Rp ' . number_format((float)$angka, 0, ',', '.');
}

function angka($nilai, int $desimal = 2): string
{
    return number_format((float)$nilai, $desimal, ',', '.');
}

function pesan_set(string $jenis, string $teks)
{
    $_SESSION['pesan'] = ['jenis' => $jenis, 'teks' => $teks];
}

function pesan_ambil(): ?array
{
    if (empty($_SESSION['pesan'])) {
        return null;
    }
    $p = $_SESSION['pesan'];
    unset($_SESSION['pesan']);
    return $p;
}

/* ------------------------------------------------------------------ */
/* Referensi                                                           */
/* ------------------------------------------------------------------ */

function ambil_daftar(mysqli $k, string $tabel, string $kolom_id, string $urut = 'nama'): array
{
    $hasil = [];
    $q = mysqli_query($k, "SELECT * FROM `$tabel` WHERE aktif = 1 ORDER BY $urut");
    while ($b = mysqli_fetch_assoc($q)) {
        $hasil[] = $b;
    }
    return $hasil;
}

function ambil_kriteria(mysqli $k): array
{
    $hasil = [];
    $q = mysqli_query($k, "SELECT * FROM tb_kriteria WHERE aktif = 1 ORDER BY urut, id_kriteria");
    while ($b = mysqli_fetch_assoc($q)) {
        $hasil[] = $b;
    }
    return $hasil;
}

function ambil_kategori(mysqli $k): array
{
    $hasil = [];
    $q = mysqli_query($k, "SELECT * FROM tb_kategori ORDER BY batas_bawah DESC");
    while ($b = mysqli_fetch_assoc($q)) {
        $hasil[] = $b;
    }
    return $hasil;
}

/**
 * Daftar kecamatan untuk pilihan formulir.
 * Akun kecamatan hanya mendapat kecamatannya sendiri.
 */
function ambil_kecamatan_pilihan(mysqli $k): array
{
    $semua = ambil_daftar($k, 'tb_kecamatan', 'id_kecamatan');
    if (kec_user() === 0) {
        return $semua;
    }
    return array_values(array_filter($semua, function ($r) {
        return (int)$r['id_kecamatan'] === kec_user();
    }));
}

/**
 * Peta desa per kecamatan dari tabel master: [id_kecamatan => [nama desa, ...]].
 * Dipakai untuk pilihan desa yang bergantung pada kecamatan.
 */
function ambil_peta_desa(mysqli $k, bool $hanya_aktif = true): array
{
    $peta = [];
    $syarat = $hanya_aktif ? 'WHERE aktif = 1' : '';
    $q = mysqli_query($k, "SELECT id_kecamatan, nama FROM tb_desa $syarat ORDER BY nama");
    if (!$q) {
        return $peta;
    }
    while ($b = mysqli_fetch_assoc($q)) {
        $peta[(int)$b['id_kecamatan']][] = $b['nama'];
    }
    return $peta;
}

function total_bobot(mysqli $k): float
{
    $q = mysqli_query($k, "SELECT COALESCE(SUM(bobot),0) AS t FROM tb_kriteria WHERE aktif = 1");
    return (float)mysqli_fetch_assoc($q)['t'];
}

/* ------------------------------------------------------------------ */
/* Inti skoring                                                        */
/* ------------------------------------------------------------------ */

/**
 * Nilai satu kriteria = (skor / skala maksimum) x bobot.
 * Rumus ini sama dengan lembar kerja Excel: M2/5*25 dan seterusnya.
 */
function hitung_nilai_kriteria($skor, $bobot, $skala_maks = 5): float
{
    $skala_maks = (int)$skala_maks > 0 ? (int)$skala_maks : 5;
    return round(((float)$skor / $skala_maks) * (float)$bobot, 2);
}

/**
 * Total nilai 0-100 dari pasangan id_kriteria => skor.
 * Mengembalikan array rincian dan total agar perhitungan dapat ditelusuri.
 */
function hitung_total_nilai(array $daftar_kriteria, array $skor_masukan): array
{
    $rincian = [];
    $total   = 0.0;

    foreach ($daftar_kriteria as $kr) {
        $id   = (int)$kr['id_kriteria'];
        $skor = isset($skor_masukan[$id]) ? (int)$skor_masukan[$id] : 0;
        if ($skor < 1) {
            $skor = 1;
        }
        if ($skor > (int)$kr['skala_maks']) {
            $skor = (int)$kr['skala_maks'];
        }
        $nilai = hitung_nilai_kriteria($skor, $kr['bobot'], $kr['skala_maks']);
        $total += $nilai;

        $rincian[] = [
            'id_kriteria' => $id,
            'kode'        => $kr['kode'],
            'nama'        => $kr['nama'],
            'skor'        => $skor,
            'bobot'       => (float)$kr['bobot'],
            'skala_maks'  => (int)$kr['skala_maks'],
            'nilai'       => $nilai,
        ];
    }

    return ['rincian' => $rincian, 'total' => round($total, 2)];
}

/**
 * Kategori prioritas ditentukan dari ambang batas bawah pada tb_kategori.
 */
function tentukan_kategori(array $daftar_kategori, float $total): ?array
{
    foreach ($daftar_kategori as $kat) {
        if ($total >= (float)$kat['batas_bawah']) {
            return $kat;
        }
    }
    return null;
}

/**
 * Simpan rincian skor lalu perbarui total dan kategori pada usulan.
 */
function simpan_skor(mysqli $k, int $id_usulan, array $skor_masukan): array
{
    $kriteria = ambil_kriteria($k);
    $kategori = ambil_kategori($k);
    $hitung   = hitung_total_nilai($kriteria, $skor_masukan);
    $kat      = tentukan_kategori($kategori, $hitung['total']);

    mysqli_query($k, "DELETE FROM tb_usulan_skor WHERE id_usulan = " . (int)$id_usulan);

    $stmt = mysqli_prepare($k, "INSERT INTO tb_usulan_skor
        (id_usulan, id_kriteria, skor, bobot, skala_maks, nilai)
        VALUES (?,?,?,?,?,?)");
    foreach ($hitung['rincian'] as $r) {
        mysqli_stmt_bind_param(
            $stmt, 'iiidid',
            $id_usulan, $r['id_kriteria'], $r['skor'], $r['bobot'], $r['skala_maks'], $r['nilai']
        );
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);

    $id_kat = $kat ? (int)$kat['id_kategori'] : null;
    $stmt = mysqli_prepare($k, "UPDATE tb_usulan SET total_nilai = ?, id_kategori = ? WHERE id_usulan = ?");
    mysqli_stmt_bind_param($stmt, 'dii', $hitung['total'], $id_kat, $id_usulan);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    return ['total' => $hitung['total'], 'kategori' => $kat];
}

/**
 * Hitung ulang seluruh usulan. Dipakai setelah bobot atau ambang kategori diubah.
 */
function hitung_ulang_semua(mysqli $k): int
{
    $jumlah = 0;
    $q = mysqli_query($k, "SELECT id_usulan FROM tb_usulan");
    $daftar = [];
    while ($b = mysqli_fetch_assoc($q)) {
        $daftar[] = (int)$b['id_usulan'];
    }
    foreach ($daftar as $id) {
        $skor = [];
        $qs = mysqli_query($k, "SELECT id_kriteria, skor FROM tb_usulan_skor WHERE id_usulan = $id");
        while ($bs = mysqli_fetch_assoc($qs)) {
            $skor[(int)$bs['id_kriteria']] = (int)$bs['skor'];
        }
        if ($skor) {
            simpan_skor($k, $id, $skor);
            $jumlah++;
        }
    }
    return $jumlah;
}

/* ------------------------------------------------------------------ */
/* Kode usulan dan log                                                 */
/* ------------------------------------------------------------------ */

function buat_kode_usulan(mysqli $k, int $tahun, string $nama_kecamatan): string
{
    $slug = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $nama_kecamatan));
    $slug = substr($slug, 0, 12);
    $awalan = "USL-$tahun-$slug-";

    $stmt = mysqli_prepare($k, "SELECT kode_usulan FROM tb_usulan
        WHERE kode_usulan LIKE CONCAT(?, '%') ORDER BY kode_usulan DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $awalan);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $terakhir = mysqli_fetch_assoc($res)['kode_usulan'] ?? null;
    mysqli_stmt_close($stmt);

    $urut = 1;
    if ($terakhir) {
        $urut = (int)substr($terakhir, -4) + 1;
    }
    return $awalan . str_pad((string)$urut, 4, '0', STR_PAD_LEFT);
}

function catat_log(mysqli $k, string $aksi, string $objek = '', string $keterangan = '')
{
    $id_user  = $_SESSION['id_user'] ?? null;
    $username = $_SESSION['username'] ?? null;
    $ip       = $_SERVER['REMOTE_ADDR'] ?? null;

    $stmt = mysqli_prepare($k, "INSERT INTO tb_log (id_user, username, aksi, objek, keterangan, ip)
        VALUES (?,?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt, 'isssss', $id_user, $username, $aksi, $objek, $keterangan, $ip);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/* ------------------------------------------------------------------ */
/* Kueri usulan dengan penyaring                                       */
/* ------------------------------------------------------------------ */

/**
 * Membangun potongan WHERE beserta parameter dari penyaring GET.
 */
function bangun_filter(array $g): array
{
    $syarat = ['1=1'];
    $tipe   = '';
    $nilai  = [];

    if (!empty($g['tahun'])) {
        $syarat[] = 'u.tahun = ?';
        $tipe .= 'i';
        $nilai[] = (int)$g['tahun'];
    }
    /* Akun kecamatan selalu dikunci pada kecamatannya sendiri */
    if (kec_user() > 0) {
        $g['kecamatan'] = kec_user();
    }
    if (!empty($g['kecamatan'])) {
        $syarat[] = 'u.id_kecamatan = ?';
        $tipe .= 'i';
        $nilai[] = (int)$g['kecamatan'];
    }
    if (!empty($g['desa'])) {
        $syarat[] = 'u.desa = ?';
        $tipe .= 's';
        $nilai[] = (string)$g['desa'];
    }
    if (!empty($g['sektor'])) {
        $syarat[] = 'u.id_sektor = ?';
        $tipe .= 'i';
        $nilai[] = (int)$g['sektor'];
    }
    if (!empty($g['opd'])) {
        $syarat[] = 'u.id_opd = ?';
        $tipe .= 'i';
        $nilai[] = (int)$g['opd'];
    }
    if (!empty($g['kategori'])) {
        $syarat[] = 'u.id_kategori = ?';
        $tipe .= 'i';
        $nilai[] = (int)$g['kategori'];
    }
    if (!empty($g['status'])) {
        $syarat[] = 'u.status = ?';
        $tipe .= 's';
        $nilai[] = $g['status'];
    }
    if (($g['penilaian'] ?? '') === 'belum') {
        $syarat[] = 'u.total_nilai IS NULL';
    } elseif (($g['penilaian'] ?? '') === 'sudah') {
        $syarat[] = 'u.total_nilai IS NOT NULL';
    }
    if (!empty($g['cari'])) {
        $syarat[] = '(u.nama_usulan LIKE ? OR u.desa LIKE ? OR u.kode_usulan LIKE ?)';
        $tipe .= 'sss';
        $kata = '%' . $g['cari'] . '%';
        $nilai[] = $kata;
        $nilai[] = $kata;
        $nilai[] = $kata;
    }

    return ['where' => implode(' AND ', $syarat), 'tipe' => $tipe, 'nilai' => $nilai];
}

function jalankan(mysqli $k, string $sql, string $tipe = '', array $nilai = [])
{
    $stmt = mysqli_prepare($k, $sql);
    if (!$stmt) {
        die('Kueri gagal: ' . e(mysqli_error($k)));
    }
    if ($tipe !== '') {
        mysqli_stmt_bind_param($stmt, $tipe, ...$nilai);
    }
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $baris = [];
    if ($res) {
        while ($b = mysqli_fetch_assoc($res)) {
            $baris[] = $b;
        }
    }
    mysqli_stmt_close($stmt);
    return $baris;
}

const SQL_USULAN_DASAR = "
    SELECT u.*, kec.nama AS kecamatan, s.nama AS sektor, s.warna AS warna_sektor,
           o.nama AS opd, sm.nama AS sumber, kat.nama AS kategori, kat.warna AS warna_kategori
    FROM tb_usulan u
    JOIN tb_kecamatan kec ON kec.id_kecamatan = u.id_kecamatan
    JOIN tb_sektor s      ON s.id_sektor      = u.id_sektor
    JOIN tb_opd o         ON o.id_opd         = u.id_opd
    JOIN tb_sumber_usulan sm ON sm.id_sumber  = u.id_sumber
    LEFT JOIN tb_kategori kat ON kat.id_kategori = u.id_kategori
";
