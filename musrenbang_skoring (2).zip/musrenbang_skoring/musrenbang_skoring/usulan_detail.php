<?php
require_once __DIR__ . '/includes/fungsi.php';
wajib_login();

$halaman_aktif = 'usulan';
$judul_halaman = 'Detail usulan';

$id = (int)($_GET['id'] ?? 0);
$baris = jalankan($koneksi, SQL_USULAN_DASAR . " WHERE u.id_usulan = ?", 'i', [$id]);
if (!$baris) {
    pesan_set('galat', 'Usulan tidak ditemukan.');
    header('Location: usulan.php');
    exit;
}
$u = $baris[0];
if (!boleh_kecamatan((int)$u['id_kecamatan'])) {
    pesan_set('galat', 'Usulan ini berada di luar kecamatan akun Anda.');
    header('Location: usulan.php');
    exit;
}

$rincian = jalankan($koneksi, "
    SELECT s.*, k.kode, k.nama
    FROM tb_usulan_skor s
    JOIN tb_kriteria k ON k.id_kriteria = s.id_kriteria
    WHERE s.id_usulan = ? ORDER BY k.urut", 'i', [$id]);

/* Peringkat dihitung terhadap seluruh usulan pada tahun yang sama */
$peringkat = jalankan($koneksi, "
    SELECT COUNT(*) + 1 AS posisi FROM tb_usulan
    WHERE tahun = ? AND total_nilai > ?", 'id', [$u['tahun'], $u['total_nilai']])[0]['posisi'];
$jumlah_tahun = jalankan($koneksi, "
    SELECT COUNT(*) AS n FROM tb_usulan WHERE tahun = ? AND total_nilai IS NOT NULL",
    'i', [$u['tahun']])[0]['n'];

require_once __DIR__ . '/includes/header.php';
?>

<div class="flex flex-wrap gap-2 mb-4 cetak-sembunyi">
  <a href="usulan.php" class="tombol-2">Kembali ke daftar</a>
  <a href="usulan_form.php?id=<?= $id ?>" class="tombol">Ubah usulan</a>
  <button onclick="window.print()" class="tombol-2">Cetak lembar verifikasi</button>
</div>

<div class="grid gap-5 lg:grid-cols-3">
  <div class="lg:col-span-2 space-y-5">

    <div class="kartu p-5">
      <p class="text-xs text-slate-500"><?= e($u['kode_usulan']) ?> &middot; tahun rencana <?= (int)$u['tahun'] ?></p>
      <h2 class="text-xl font-bold text-slate-900 mt-1"><?= e($u['nama_usulan']) ?></h2>
      <p class="text-sm text-slate-600 mt-2"><?= nl2br(e($u['uraian_masalah'])) ?></p>

      <div class="grid gap-4 md:grid-cols-3 mt-5 text-sm">
        <div><p class="text-xs text-slate-500">Lokasi</p><p class="font-medium"><?= e($u['desa']) ?>, <?= e($u['kecamatan']) ?></p></div>
        <div><p class="text-xs text-slate-500">Sumber usulan</p><p class="font-medium"><?= e($u['sumber']) ?></p></div>
        <div><p class="text-xs text-slate-500">Sektor</p><p class="font-medium"><?= e($u['sektor']) ?></p></div>
        <div><p class="text-xs text-slate-500">OPD penanggung jawab</p><p class="font-medium"><?= e($u['opd']) ?></p></div>
        <div><p class="text-xs text-slate-500">Volume</p><p class="font-medium"><?= angka($u['volume'], 0) ?> <?= e($u['satuan']) ?></p></div>
        <div><p class="text-xs text-slate-500">Estimasi anggaran</p><p class="font-medium"><?= rupiah($u['estimasi_anggaran']) ?></p></div>
        <div><p class="text-xs text-slate-500">Status</p><p class="font-medium"><?= e($u['status']) ?></p></div>
        <div class="md:col-span-2"><p class="text-xs text-slate-500">Catatan verifikasi</p>
            <p class="font-medium"><?= $u['catatan_verifikasi'] ? nl2br(e($u['catatan_verifikasi'])) : '-' ?></p></div>
      </div>
    </div>

    <div class="kartu p-5">
      <p class="font-semibold text-sm text-slate-800 mb-1">Rincian perhitungan nilai</p>
      <p class="text-xs text-slate-500 mb-4">
        Bobot yang tercatat di bawah adalah bobot yang dipakai saat penilaian disimpan.
      </p>
      <table class="data w-full">
        <thead>
          <tr><th>Kode</th><th>Kriteria</th><th class="text-right">Skor</th>
              <th class="text-right">Skala</th><th class="text-right">Bobot</th>
              <th class="text-right">Nilai</th></tr>
        </thead>
        <tbody>
        <?php foreach ($rincian as $r): ?>
          <tr>
            <td class="text-slate-500"><?= e($r['kode']) ?></td>
            <td><?= e($r['nama']) ?></td>
            <td class="text-right"><?= (int)$r['skor'] ?></td>
            <td class="text-right"><?= (int)$r['skala_maks'] ?></td>
            <td class="text-right"><?= angka($r['bobot']) ?></td>
            <td class="text-right font-semibold"><?= angka($r['nilai']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr class="bg-slate-50">
            <td colspan="4" class="font-semibold">Nilai akhir</td>
            <td class="text-right font-semibold"><?= angka(array_sum(array_column($rincian, 'bobot'))) ?></td>
            <td class="text-right font-bold"><?= angka($u['total_nilai']) ?></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <div class="kartu p-5 hidden print:block">
      <p class="font-semibold text-sm mb-8">Mengetahui,</p>
      <div class="grid grid-cols-2 gap-8 text-sm">
        <div><p>Verifikator</p><div style="height:60px"></div><p>(..............................)</p></div>
        <div><p>Kepala Bappeda Kabupaten Banggai</p><div style="height:60px"></div><p>(..............................)</p></div>
      </div>
    </div>

  </div>

  <div class="space-y-5">
    <div class="kartu p-5">
      <p class="text-xs text-slate-500">Nilai akhir</p>
      <p class="text-4xl font-bold text-slate-900"><?= angka($u['total_nilai']) ?></p>
      <p class="mt-2"><span class="lencana" style="background:<?= e($u['warna_kategori'] ?: '#64748B') ?>">
        <?= e($u['kategori'] ?: 'Belum dinilai') ?></span></p>
      <div class="mt-4 pt-4 border-t border-slate-200 text-sm">
        <p class="text-xs text-slate-500">Peringkat tahun <?= (int)$u['tahun'] ?></p>
        <p class="font-semibold"><?= (int)$peringkat ?> dari <?= (int)$jumlah_tahun ?> usulan</p>
      </div>
      <div class="mt-4 pt-4 border-t border-slate-200 text-xs text-slate-500">
        <p>Dibuat <?= date('d/m/Y H:i', strtotime($u['dibuat_pada'])) ?></p>
        <p>Diubah <?= date('d/m/Y H:i', strtotime($u['diubah_pada'])) ?></p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
