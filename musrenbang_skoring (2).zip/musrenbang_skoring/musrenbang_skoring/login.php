<?php
require_once __DIR__ . '/includes/fungsi.php';

if (!empty($_SESSION['id_user'])) {
    header('Location: dashboard.php');
    exit;
}

$galat = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $sandi    = $_POST['password'] ?? '';

    $baris = jalankan($koneksi,
        "SELECT u.*, k.nama AS nama_kecamatan FROM tb_user u
         LEFT JOIN tb_kecamatan k ON k.id_kecamatan = u.id_kecamatan
         WHERE u.username = ? AND u.aktif = 1 LIMIT 1", 's', [$username]);

    if ($baris && password_verify($sandi, $baris[0]['password'])) {
        $u = $baris[0];
        session_regenerate_id(true);
        $_SESSION['id_user']      = (int)$u['id_user'];
        $_SESSION['username']     = $u['username'];
        $_SESSION['nama_lengkap'] = $u['nama_lengkap'];
        $_SESSION['role']         = $u['role'];
        $_SESSION['id_kecamatan'] = (int)$u['id_kecamatan'];
        $_SESSION['nama_kecamatan'] = $u['nama_kecamatan'] ?? '';
        catat_log($koneksi, 'masuk', 'tb_user', 'Berhasil masuk');
        header('Location: dashboard.php');
        exit;
    }
    $galat = 'Nama pengguna atau kata sandi tidak cocok.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Masuk &middot; <?= APP_NAMA ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<style>body{font-family:ui-sans-serif,system-ui,"Segoe UI",Roboto,Arial,sans-serif}</style>
</head>
<body class="min-h-screen grid md:grid-cols-2" style="background:#F6F5F1">

  <div class="hidden md:flex flex-col justify-between p-10 text-white" style="background:#0B3B37">
    <div>
      <p class="text-2xl font-bold"><?= APP_NAMA ?></p>
      <p class="text-slate-300 mt-2 text-sm max-w-sm"><?= APP_SUBJUDUL ?> pada <?= APP_INSTANSI ?>.</p>
    </div>
    <div class="text-sm text-slate-300 max-w-md leading-relaxed">
      <p class="font-semibold text-white mb-2">Enam kriteria penilaian</p>
      <p>Urgensi 25 &middot; Dampak dan manfaat 20 &middot; Prioritas pembangunan 15 &middot;
         Kelayakan teknis dan kewenangan 20 &middot; Partisipasi 10 &middot; Kesiapan 10.</p>
      <p class="mt-3">Nilai akhir berskala 0 sampai 100. Setiap komponen tersimpan sehingga hasil dapat ditelusuri ulang.</p>
    </div>
  </div>

  <div class="flex items-center justify-center p-8">
    <div class="w-full max-w-sm">
    <a href="index.php" class="inline-block text-sm mb-4" style="color:#0F766E">&larr; Kembali ke beranda</a>
    <form method="post" class="w-full bg-white border border-slate-200 rounded-xl p-7">
      <h1 class="text-lg font-semibold text-slate-900">Masuk ke aplikasi</h1>
      <p class="text-sm text-slate-500 mt-1 mb-5">Gunakan akun yang diberikan administrator.</p>

      <?php if ($galat): ?>
        <p class="mb-4 text-sm bg-rose-50 border border-rose-200 text-rose-800 rounded-lg px-3 py-2"><?= e($galat) ?></p>
      <?php endif; ?>

      <label class="block text-sm font-medium text-slate-700 mb-1">Nama pengguna</label>
      <input name="username" required autofocus
             class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm mb-4">

      <label class="block text-sm font-medium text-slate-700 mb-1">Kata sandi</label>
      <input type="password" name="password" required
             class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm mb-5">

      <button class="w-full text-white font-semibold rounded-lg py-2.5 text-sm" style="background:#0F766E">Masuk</button>

      <p class="mt-5 text-xs text-slate-500 leading-relaxed">
        Akun bawaan: <b>admin / admin123</b>. Akun kecamatan memakai pola
        <b>kec_namakecamatan</b>, misalnya <b>kec_luwuk_selatan</b>, dengan sandi awal <b>kecamatan123</b>.
        Ganti kata sandi setelah aplikasi dipasang.
      </p>
    </form>
    </div>
  </div>

</body>
</html>
